AirWick nRF52840 v0.22 — conservative energy optimization

Base: v0.21 final stable. Autonomous behavior, persistent settings, endpoint,
clusters, selector thresholds, spray timing, pairing/reset state machine,
watchdog and network recovery are retained.

Changes intentionally limited to low-risk energy improvements:
- Normal sleepy-end-device Zigbee long poll: 2 s -> 5 s.
  Commissioning/turbo poll is unchanged. A remote command can therefore have
  up to roughly 5 s latency while the device is asleep.
- AUTO keeps the v0.21 exact monotonic deadline behavior.
- SCHEDULE and PROGRAMMABLE no longer wake the scheduler every 30 s.
  The firmware uses the already-computed next_spray_time and sleeps directly
  until the next event. Selector/config/time-sync changes still reschedule the
  scheduler immediately.
- Physical selector stable scan: 1 s -> 2 s. On detecting a possible change,
  a second debounce sample is taken after 100 ms, preserving fast response.
- Board status LED output is disabled in normal firmware. Pairing/Identify
  protocol logic remains intact; the GPIO is simply kept off.
- Standard battery voltage and battery percentage attributes are explicitly
  marked for normal ZCL reporting after each 30-minute measurement, to prevent
  stale battery-percent UI while preserving the existing custom millivolt value.

Deliberately NOT changed in this conservative build:
- motor pulse 600 ms and 5 s lockout;
- report/retry logic used by the stable UI;
- hourly wall-clock checkpoint, to retain the v0.21 offline/reboot fallback;
- battery sample period and verified battery curve;
- ZBOSS health/watchdog/recovery timings;
- DC/DC regulator mode. The exact ProMicro/nice!nano clone power stage has not
  been hardware-verified, so v0.22 does not force a regulator mode that could
  be unsafe on an incompatible clone.

Hardware divider used by this project remains 1:1. No hardware wiring changes
are required for v0.22.

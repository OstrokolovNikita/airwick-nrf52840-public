#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "../src/airwick_auto_math.h"

int main(void) {
    const int64_t t = 60000;
    const int64_t span = 1800000;
    // A due slot must stay due. The previous v0.22 reconcile used to push it away.
    assert(airwick_auto_remaining_seconds(t - t) == 0);
    assert(airwick_auto_remaining_seconds(t - (t - 1)) == 1);
    assert(airwick_auto_remaining_seconds(t - (t - 1001)) == 2);
    assert(airwick_auto_next_deadline(t,t,span) == 1860000);
    assert(airwick_auto_next_deadline(t,t+1,span) == 1860000);
    assert(airwick_auto_next_deadline(t,t+span-1,span) == 1860000);
    assert(airwick_auto_next_deadline(t,t+span,span) == 3660000);
    assert(airwick_auto_next_deadline(t,t+span*1000+1,span) == t + span*1001);
    // Manual spray at 08:10 does not shift an autonomous 08:30 slot.
    assert(airwick_auto_next_deadline(8*3600000LL+30*60000LL,
          8*3600000LL+30*60000LL,span) == 9*3600000LL);
    puts("AUTO_MATH_TESTS_PASS 9 assertions");
    return 0;
}

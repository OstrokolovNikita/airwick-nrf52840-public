AirWick nRF52840 v0.26 — EXPERIMENTAL, NOT YET FIELD-TESTED
=========================================================
Based on the SHA-verified source of field-stable v0.22; v0.23/v0.24 changes are excluded.
Zigbee long poll remains the v0.22 value (5 s), selector remains 2 s.

FIXES:
1. AUTO: due monotonic deadline is never reset by reconciling with UTC.
2. Clock: keeps time without Zigbee while powered. On cold boot, NVS UTC is NOT
   treated as correct time: with no battery-backed RTC we cannot know power-off
   duration. SCHEDULE/PROGRAMMABLE wait for new sync, AUTO still runs via uptime.
3. Hourly NVS clock writes removed; save a checkpoint only on real sync.
4. Motor pulse reserved atomically before counter/timer, preventing dual callers.
5. Watchdog heartbeat 45 s versus 120 s timeout (formerly both were 120 s).
6. Converter computes Li-ion % from ALREADY sent batteryMv, no new packets.
7. Converter no longer launches 9+ burst reads on every deviceAnnounce.

Hardware/wiring, NVS layout, Zigbee clusters, motor 600 ms, lockout 5 s unchanged.
Check control button/selector, AUTO across deadline, offline schedule while powered,
new clock sync after cold boot and command reception after 1-2 hours. Do not reset
or delete the existing device when upgrading. Rollback to v0.22 UF2 if needed.

#pragma once

#include <stdbool.h>
#include <stdint.h>

#define AIRWICK_PROGRAM_SLOTS 7U
#define AIRWICK_TIME_INVALID UINT32_C(0xffffffff)
#define AIRWICK_MINUTES_PER_DAY 1440U

/* User-visible operating modes. */
enum airwick_mode {
    AIRWICK_MODE_OFF = 0,
    AIRWICK_MODE_AUTO = 1,
    AIRWICK_MODE_SCHEDULE = 2,
    AIRWICK_MODE_PROGRAMMABLE = 3,
};

/* Why a spray happened. Values are persisted and exported over Zigbee. */
enum airwick_spray_reason {
    AIRWICK_REASON_NONE = 0,
    AIRWICK_REASON_REMOTE = 1,
    AIRWICK_REASON_BUTTON = 2,
    AIRWICK_REASON_AUTO = 3,
    AIRWICK_REASON_SCHEDULE = 4,
    AIRWICK_REASON_PROGRAMMABLE = 5,
};

/* v0.16 uses one slot per weekday (slot 0=Mon ... slot 6=Sun). */
struct airwick_program_slot {
    uint8_t enabled;
    uint8_t days_mask;
    uint16_t start_minute;
    uint16_t end_minute;
    uint16_t interval_minute;
};

/* Persistent user configuration. Do not reorder fields without bumping version. */
struct airwick_config {
    uint32_t magic;
    uint16_t version;
    uint16_t size;

    uint8_t mode;
    uint8_t schedule_days_mask;
    int16_t timezone_minutes;

    uint16_t auto_interval_minute;
    uint16_t schedule_start_minute;
    uint16_t schedule_end_minute;
    uint16_t schedule_interval_minute;

    uint8_t startup_on_off;
    uint8_t selector_enabled; /* reserved for the future 4-position hardware selector */
    uint16_t spray_duration_ms; /* former v2 reserved0: 0 from older firmware means 600 ms */

    struct airwick_program_slot program[AIRWICK_PROGRAM_SLOTS];
};

/* Persistent counters/runtime anchors. */
struct airwick_stats {
    uint32_t magic;
    uint16_t version;
    uint16_t size;

    uint32_t spray_count;
    uint32_t last_spray_time;       /* Zigbee UTC seconds since 2000, or AIRWICK_TIME_INVALID */
    uint32_t next_spray_time;       /* same epoch, or AIRWICK_TIME_INVALID */
    uint32_t last_schedule_token;   /* local minute token, prevents duplicate schedule fires */
    uint32_t fallback_remaining_sec;/* AUTO fallback when wall clock is unavailable */

    uint8_t last_spray_reason;
    uint8_t controlled_reboot;
    uint16_t reserved0;
};

int airwick_state_init(void);
struct airwick_config *airwick_config_get(void);
struct airwick_stats *airwick_stats_get(void);

int airwick_config_save(void);
int airwick_stats_save(void);

/* Erases only AirWick application settings/stats. Zigbee network reset is separate. */
int airwick_state_factory_erase(void);

void airwick_config_defaults(struct airwick_config *cfg);
void airwick_stats_defaults(struct airwick_stats *stats);
bool airwick_config_valid(const struct airwick_config *cfg);
bool airwick_stats_valid(const struct airwick_stats *stats);

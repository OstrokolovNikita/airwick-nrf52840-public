#pragma once

#include <stdbool.h>
#include <stdint.h>
#include "airwick_state.h"

/*
 * All public times are Zigbee UTC seconds since 2000-01-01 00:00:00 UTC.
 * Week mask: bit0 Monday ... bit6 Sunday.
 */

bool airwick_schedule_due(const struct airwick_config *cfg,
                          uint32_t utc_now,
                          uint32_t last_token,
                          uint32_t *token_out,
                          uint8_t *reason_out);

/* Returns AIRWICK_TIME_INVALID if no future event exists in the next 8 days. */
uint32_t airwick_schedule_next(const struct airwick_config *cfg,
                               uint32_t utc_now,
                               uint32_t last_token);

/* Useful for persistence/debugging; one unique token per local minute. */
uint32_t airwick_local_minute_token(uint32_t utc_now, int16_t timezone_minutes);

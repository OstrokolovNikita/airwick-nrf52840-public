/* Pure monotonic AUTO deadline arithmetic — no Zephyr/Zigbee dependencies. */
#ifndef AIRWICK_AUTO_MATH_H_
#define AIRWICK_AUTO_MATH_H_
#include <stdint.h>

static inline uint32_t airwick_auto_remaining_seconds(int64_t remaining_ms)
{
    if (remaining_ms <= 0) return 0U;
    return (uint32_t)(((uint64_t)remaining_ms + 999ULL) / 1000ULL);
}

static inline int64_t airwick_auto_next_deadline(int64_t due_ms, int64_t now_ms,
                                                  int64_t interval_ms)
{
    /* Caller supplies a due deadline and a positive interval. Skip missed slots
     * in one operation; do not burst accumulated sprays after delayed wakeup. */
    return due_ms + ((now_ms - due_ms) / interval_ms + 1LL) * interval_ms;
}
#endif

#include "airwick_schedule.h"

#include <stddef.h>

#define SEC_PER_MIN 60LL
#define MIN_PER_DAY 1440LL
#define SEC_PER_DAY (SEC_PER_MIN * MIN_PER_DAY)
#define SEARCH_MINUTES (8U * 1440U)
#define FIXED_WEEKDAY_MASK 0x1fU
#define FIXED_WEEKEND_MASK 0x60U
#define FIXED_WEEKDAY_START_MIN (7U * 60U)
#define FIXED_WEEKEND_START_MIN (9U * 60U)
#define FIXED_END_MIN (22U * 60U)
#define FIXED_INTERVAL_MIN 30U

struct local_clock_parts {
    int64_t day_index;
    uint16_t minute_of_day;
    uint8_t weekday; /* 0 Monday ... 6 Sunday */
};

static struct local_clock_parts local_parts(uint32_t utc_now, int16_t timezone_minutes)
{
    int64_t local_sec = (int64_t)utc_now + (int64_t)timezone_minutes * SEC_PER_MIN;
    int64_t day = local_sec / SEC_PER_DAY;
    int64_t rem = local_sec % SEC_PER_DAY;
    if (rem < 0) {
        rem += SEC_PER_DAY;
        day--;
    }

    /* 2000-01-01 was Saturday. With Monday=0, Saturday=5. */
    int64_t weekday = (day + 5LL) % 7LL;
    if (weekday < 0) {
        weekday += 7LL;
    }

    struct local_clock_parts out = {
        .day_index = day,
        .minute_of_day = (uint16_t)(rem / SEC_PER_MIN),
        .weekday = (uint8_t)weekday,
    };
    return out;
}

uint32_t airwick_local_minute_token(uint32_t utc_now, int16_t timezone_minutes)
{
    struct local_clock_parts p = local_parts(utc_now, timezone_minutes);
    if (p.day_index < 0) {
        return AIRWICK_TIME_INVALID;
    }
    uint64_t token = (uint64_t)p.day_index * 1440ULL + p.minute_of_day;
    return token > UINT32_MAX ? AIRWICK_TIME_INVALID : (uint32_t)token;
}

static bool day_selected(uint8_t mask, uint8_t weekday)
{
    return (mask & (uint8_t)(1U << weekday)) != 0U;
}

/*
 * start < end: ordinary same-day window [start, end)
 * start > end: cross-midnight window, and the after-midnight part belongs to
 *              the previous selected day.
 * start == end: intentionally disabled, rather than interpreting as 24 h.
 */
static bool window_due(uint8_t days_mask,
                       uint16_t start,
                       uint16_t end,
                       uint16_t interval,
                       const struct local_clock_parts *p)
{
    if (days_mask == 0U || interval == 0U || start >= AIRWICK_MINUTES_PER_DAY ||
        end >= AIRWICK_MINUTES_PER_DAY || start == end) {
        return false;
    }

    uint32_t elapsed;
    uint8_t owner_day;

    if (start < end) {
        if (p->minute_of_day < start || p->minute_of_day >= end) {
            return false;
        }
        owner_day = p->weekday;
        elapsed = (uint32_t)p->minute_of_day - start;
    } else {
        if (p->minute_of_day >= start) {
            owner_day = p->weekday;
            elapsed = (uint32_t)p->minute_of_day - start;
        } else if (p->minute_of_day < end) {
            owner_day = (uint8_t)((p->weekday + 6U) % 7U);
            elapsed = (uint32_t)(AIRWICK_MINUTES_PER_DAY - start) + p->minute_of_day;
        } else {
            return false;
        }
    }

    return day_selected(days_mask, owner_day) && (elapsed % interval) == 0U;
}

bool airwick_schedule_due(const struct airwick_config *cfg,
                          uint32_t utc_now,
                          uint32_t last_token,
                          uint32_t *token_out,
                          uint8_t *reason_out)
{
    if (cfg == NULL || utc_now == AIRWICK_TIME_INVALID) {
        return false;
    }

    uint32_t token = airwick_local_minute_token(utc_now, cfg->timezone_minutes);
    if (token == AIRWICK_TIME_INVALID || token == last_token) {
        return false;
    }

    struct local_clock_parts p = local_parts(utc_now, cfg->timezone_minutes);
    bool due = false;
    uint8_t reason = AIRWICK_REASON_NONE;

    if (cfg->mode == AIRWICK_MODE_SCHEDULE) {
        /* Built-in schedule is intentionally not user-editable:
         * Mon-Fri 07:00-22:00, Sat-Sun 09:00-22:00, every 30 minutes. */
        due = window_due(FIXED_WEEKDAY_MASK,
                         FIXED_WEEKDAY_START_MIN,
                         FIXED_END_MIN,
                         FIXED_INTERVAL_MIN,
                         &p) ||
              window_due(FIXED_WEEKEND_MASK,
                         FIXED_WEEKEND_START_MIN,
                         FIXED_END_MIN,
                         FIXED_INTERVAL_MIN,
                         &p);
        reason = AIRWICK_REASON_SCHEDULE;
    } else if (cfg->mode == AIRWICK_MODE_PROGRAMMABLE) {
        /* One independent line per weekday: enabled + start + end + interval.
         * Slot index is the weekday, so no bit-mask arithmetic is exposed to the user. */
        for (unsigned int i = 0; i < AIRWICK_PROGRAM_SLOTS; i++) {
            const struct airwick_program_slot *slot = &cfg->program[i];
            uint8_t day_mask = (uint8_t)(1U << i);
            if (slot->enabled && window_due(day_mask,
                                            slot->start_minute,
                                            slot->end_minute,
                                            slot->interval_minute,
                                            &p)) {
                due = true;
                break;
            }
        }
        reason = AIRWICK_REASON_PROGRAMMABLE;
    }

    if (!due) {
        return false;
    }
    if (token_out != NULL) {
        *token_out = token;
    }
    if (reason_out != NULL) {
        *reason_out = reason;
    }
    return true;
}

uint32_t airwick_schedule_next(const struct airwick_config *cfg,
                               uint32_t utc_now,
                               uint32_t last_token)
{
    if (cfg == NULL || utc_now == AIRWICK_TIME_INVALID ||
        (cfg->mode != AIRWICK_MODE_SCHEDULE &&
         cfg->mode != AIRWICK_MODE_PROGRAMMABLE)) {
        return AIRWICK_TIME_INVALID;
    }

    uint32_t first = utc_now - (utc_now % 60U);
    for (uint32_t i = 0; i <= SEARCH_MINUTES; i++) {
        uint64_t candidate64 = (uint64_t)first + (uint64_t)i * 60ULL;
        if (candidate64 > UINT32_MAX) {
            break;
        }
        uint32_t candidate = (uint32_t)candidate64;
        uint32_t token;
        uint8_t reason;
        if (airwick_schedule_due(cfg, candidate, last_token, &token, &reason)) {
            /* Never advertise an event that is already behind the current second. */
            if (candidate >= utc_now) {
                return candidate;
            }
        }
    }
    return AIRWICK_TIME_INVALID;
}

/* AirWick v0.27
 *
 * Stable hardware behavior retained from v0.7:
 * - P0.17 / D2: motor MOSFET gate, active HIGH, 300–1000 ms timer cutoff
 * - P0.06 / D1: action button to GND; short press = spray, hold 10 s = factory reset/pairing
 * - P0.29 / D20 / AIN5: 1S Li-ion measurement through a 1:1 external divider
 * - always a sleepy RX-off Zigbee End Device; USB never changes Zigbee role/behavior
 * - USB is hardware power/charging only; firmware does not detect or react to VBUS
 * - only endpoint 10 is exposed
 *
 * v0.13 adds the fitted four-position physical selector on 020/031.
 * 020 powers the resistor ladder only during sampling; 031 is ADC input.
 * Physical positions map directly to OFF/AUTO/SCHEDULE/PROGRAMMABLE.
 * v0.8 core retained; v0.9 adds deterministic factory-reset/pairing:
 * - a persistent pairing-pending marker survives the reset/reboot boundary
 * - local reset waits for LEAVE, with a timed reboot fallback
 * - factory-new boot explicitly starts BDB Network Steering
 * - failed steering is retried every 3 s for 15 minutes
 * - pairing LED: slow blink while searching, three short blinks on success
 * - NVS-backed persistent modes, schedules, programmable windows and counters
 * - AUTO / SCHEDULE / PROGRAMMABLE autonomous local scheduler
 * - Zigbee Time synchronization and local wall-clock anchor
 * - manufacturer-specific control cluster 0xFC00 for the future Z2M converter/UI
 * - factory reset erases AirWick application settings as well as Zigbee network data
 */

#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/adc.h>
#include <zephyr/drivers/watchdog.h>
#include <zephyr/logging/log.h>
#include <zephyr/sys/atomic.h>
#include <zephyr/sys/reboot.h>
#include <zephyr/settings/settings.h>

#include <zboss_api.h>
#include <zcl/zb_zcl_reporting.h>
#include <zcl/zb_zcl_time.h>
#include <zigbee/zigbee_error_handler.h>
#include <zigbee/zigbee_app_utils.h>
#include <zb_nrf_platform.h>

#include "airwick_state.h"
#include "airwick_schedule.h"
#include "airwick_auto_math.h"

#define AIRWICK_ENDPOINT 10

#define AIRWICK_CTRL 0xFC00U
#define AIRWICK_CTRL_CLUSTER_REVISION_DEFAULT ((zb_uint16_t)0x0001U)

#define SPRAY_PULSE_DEFAULT_MS 600U
#define SPRAY_PULSE_MIN_MS 300U
#define SPRAY_PULSE_MAX_MS 1000U
#define SPRAY_LOCKOUT_MS 5000
#define BATTERY_LONG_POLL_MS 5000
#define KEEPALIVE_MS (16UL * 60UL * 1000UL)
#define BATTERY_SAMPLE_MS (30UL * 60UL * 1000UL)
#define BUTTON_HOLD_MS 10000
#define BATTERY_DIVIDER_NUM 2U
#define BATTERY_VALID_MIN_MV 2500U
#define BATTERY_VALID_MAX_MV 4400U
#define BATTERY_SAMPLES 4U
#define IDENTIFY_MAX_SECONDS 10U
#define SCHEDULER_TICK_MS 30000
#define STATE_REPORT_RETRY_MS 1500U
#define TIME_SYNC_INITIAL_MS 3000
#define TIME_SYNC_RETRY_FAST_MS 15000UL
#define TIME_SYNC_RETRY_MEDIUM_MS 60000UL
#define TIME_SYNC_RETRY_SLOW_MS (15UL * 60UL * 1000UL)
#define TIME_SYNC_PERIOD_MS (6UL * 60UL * 60UL * 1000UL)
#define CLOCK_KEY "airwick/clock"
#define CLOCK_MAGIC UINT32_C(0x41574354) /* AWCT */
#define PAIRING_REBOOT_AFTER_LEAVE_MS 400
#define PAIRING_REBOOT_FALLBACK_MS 3000
#define PAIRING_RETRY_MS 3000
#define PAIRING_WINDOW_MS (15UL * 60UL * 1000UL)
#define PAIRING_KEY "airwick/pairing_pending"
#define NETWORK_RECOVERY_MS (2UL * 60UL * 1000UL)
#define ZBOSS_HEALTH_PERIOD_MS 45000U
#define ZBOSS_HEALTH_MAX_MISSES 3U
#define HW_WATCHDOG_TIMEOUT_MS 120000U
#define STATUS_LED_OUTPUT_ENABLED 0

/* Physical selector: 020 powers the ladder; 031 reads it through SAADC AIN7.
 * Ladder fitted on hardware:
 *   OFF -> GND
 *   AUTO -> ~20/22 kOhm from 020, 100 kOhm pulldown on 031
 *   SCHEDULE -> 100 kOhm from 020, 100 kOhm pulldown
 *   PROGRAMMABLE -> 330 kOhm from 020, 100 kOhm pulldown
 * Thresholds intentionally leave dead bands between valid positions. */
#define SELECTOR_SAMPLE_MS             2000U
#define SELECTOR_CONFIRM_MS            100U
#define SELECTOR_SETTLE_MS             3U
#define SELECTOR_SAMPLES               2U
#define SELECTOR_STABLE_SAMPLES        2U
#define SELECTOR_INVALID               0xffU
#define SELECTOR_OFF_MAX_MV            300U
#define SELECTOR_PROGRAM_MIN_MV        450U
#define SELECTOR_PROGRAM_MAX_MV        1100U
#define SELECTOR_SCHEDULE_MIN_MV       1250U
#define SELECTOR_SCHEDULE_MAX_MV       2050U
#define SELECTOR_AUTO_MIN_MV           2250U
#define SELECTOR_AUTO_MAX_MV           3150U

/* Custom cluster common attributes. */
#define AW_ATTR_MODE                    0x0000U
#define AW_ATTR_AUTO_INTERVAL_MIN       0x0001U
#define AW_ATTR_SCHEDULE_DAYS           0x0002U
#define AW_ATTR_SCHEDULE_START_MIN      0x0003U
#define AW_ATTR_SCHEDULE_END_MIN        0x0004U
#define AW_ATTR_SCHEDULE_INTERVAL_MIN   0x0005U
#define AW_ATTR_TIMEZONE_MIN            0x0006U
#define AW_ATTR_SPRAY_COUNT             0x0007U
#define AW_ATTR_LAST_SPRAY_REASON       0x0008U
#define AW_ATTR_LAST_SPRAY_TIME         0x0009U
#define AW_ATTR_NEXT_SPRAY_TIME         0x000AU
#define AW_ATTR_TIME_VALID              0x000BU
#define AW_ATTR_PHYSICAL_MODE           0x000DU
#define AW_ATTR_RESET_COUNTER           0x000EU
#define AW_ATTR_SETTINGS_VERSION        0x000FU
#define AW_ATTR_SYNC_TIME               0x0010U
#define AW_ATTR_BATTERY_MV               0x0011U
#define AW_ATTR_SPRAY_DURATION_MS        0x0012U

/* Seven weekday program blocks, 8 IDs apart. Fields 0..4 are used. */
#define AW_PROGRAM_BASE                 0x0020U
#define AW_PROGRAM_STRIDE               0x0008U
#define AW_PROGRAM_ENABLED              0U
#define AW_PROGRAM_DAYS                 1U
#define AW_PROGRAM_START                2U
#define AW_PROGRAM_END                  3U
#define AW_PROGRAM_INTERVAL             4U

LOG_MODULE_REGISTER(airwick, LOG_LEVEL_NONE);

static const struct gpio_dt_spec motor_out =
    GPIO_DT_SPEC_GET(DT_ALIAS(airwick_motor), gpios);
static const struct gpio_dt_spec selector_power =
    GPIO_DT_SPEC_GET(DT_ALIAS(airwick_selector_power), gpios);
static const struct gpio_dt_spec action_button =
    GPIO_DT_SPEC_GET(DT_ALIAS(airwick_button), gpios);
static const struct gpio_dt_spec status_led =
    GPIO_DT_SPEC_GET(DT_ALIAS(led0), gpios);
static const struct adc_dt_spec battery_adc =
    ADC_DT_SPEC_GET_BY_IDX(DT_PATH(zephyr_user), 0);
static const struct adc_dt_spec selector_adc =
    ADC_DT_SPEC_GET_BY_IDX(DT_PATH(zephyr_user), 1);

static atomic_t pulse_active;
static atomic_t identify_led_on;
static atomic_t button_long_fired;
static atomic_t network_joined;
static atomic_t factory_reset_active;
static atomic_t pairing_led_on;
static atomic_t pairing_led_mode;
static atomic_t zboss_heartbeat_counter;
static atomic_t clock_network_synced;

static int64_t last_spray_ms = -SPRAY_LOCKOUT_MS;
static uint32_t spray_count;
static bool battery_alarm_started;
static bool button_pressed;
static bool pairing_pending;
static uint8_t selector_candidate_mode = SELECTOR_INVALID;
static uint8_t selector_candidate_count;
static uint8_t selector_applied_mode = SELECTOR_INVALID;
static bool joining_signal_received;
static atomic_val_t health_last_heartbeat;
static uint8_t health_missed_heartbeats;
static atomic_t health_probe_pending;
static atomic_t time_sync_attempts;
static const struct device *watchdog_dev = DEVICE_DT_GET(DT_NODELABEL(wdt0));
static int watchdog_channel = -1;

static struct airwick_config *cfg;
static struct airwick_stats *stats;

/* v0.26 persisted config has an unused uint16_t reserved0 in exactly this slot.
 * Zero from an older image uses the historical 600-ms pulse, without erasing NVS. */
static uint16_t spray_duration_ms(void)
{
    const uint16_t ms = cfg->spray_duration_ms;
    return (ms >= SPRAY_PULSE_MIN_MS && ms <= SPRAY_PULSE_MAX_MS)
        ? ms : SPRAY_PULSE_DEFAULT_MS;
}

/* Runtime wall clock: Zigbee UTC anchor + monotonic uptime elapsed. */
static struct k_spinlock clock_lock;
static bool wall_clock_valid;
static uint32_t clock_anchor_utc;
static int64_t clock_anchor_uptime_ms;

struct airwick_clock_checkpoint {
    uint32_t magic;
    uint32_t utc;
};

/* AUTO deadline is monotonic so it keeps running while Zigbee is temporarily offline. */
static struct k_spinlock auto_lock;
static int64_t auto_deadline_ms = -1;

enum spray_reason {
    SPRAY_REASON_NONE = 0,
    SPRAY_REASON_REMOTE = 1,
    SPRAY_REASON_BUTTON = 2,
    SPRAY_REASON_AUTO = 3,
    SPRAY_REASON_SCHEDULE = 4,
    SPRAY_REASON_PROGRAMMABLE = 5,
};
static enum spray_reason last_spray_reason = SPRAY_REASON_NONE;

static struct k_timer motor_cutoff_timer;
static struct k_work_delayable motor_state_sync_work;
static struct k_work_delayable identify_work;
static struct k_work_delayable button_hold_work;
static struct k_work_delayable config_save_work;
static struct k_work_delayable stats_save_work;
static struct k_work_delayable scheduler_work;
static struct k_work_delayable time_sync_work;
static struct k_work_delayable clock_checkpoint_work;
static struct k_work control_report_work;
static struct k_work button_short_work;
static struct k_work pairing_work;
static struct k_work_delayable pairing_led_work;
static struct k_work_delayable pairing_retry_work;
static struct k_work_delayable pairing_reboot_work;
static struct k_work_delayable selector_work;
static struct k_work_delayable state_report_retry_work;
static struct k_work_delayable network_recovery_work;
static struct k_work_delayable health_work;
static struct gpio_callback button_gpio_cb;
static uint8_t identify_phase;
static int64_t identify_deadline_ms;
static uint8_t pairing_led_phase;
static int64_t pairing_deadline_ms;

/* Standard clusters. */
static zb_bool_t on_off = ZB_FALSE;
static zb_uint8_t startup_on_off = ZB_ZCL_ON_OFF_START_UP_ON_OFF_IS_PREVIOUS;
static zb_uint8_t zcl_version = ZB_ZCL_VERSION;
static zb_uint8_t app_version = 27;
static zb_uint8_t power_source = ZB_ZCL_BASIC_POWER_SOURCE_BATTERY;
static zb_uint16_t identify_time;
static zb_char_t manufacturer[] = "\003DIY";
static zb_char_t model[] = "\020AirWick_nRF52840";
static zb_char_t build_id[] = "\005v0.27";
static zb_uint8_t battery_voltage = ZB_ZCL_POWER_CONFIG_BATTERY_VOLTAGE_INVALID;
static zb_uint8_t battery_percentage_remaining = ZB_ZCL_POWER_CONFIG_BATTERY_REMAINING_UNKNOWN;

/* Standard Time cluster. It is an anchor/interface; actual running clock uses k_uptime. */
static zb_zcl_time_attrs_t time_cluster = {
    .time = ZB_ZCL_TIME_TIME_INVALID_VALUE,
    .time_status = ZB_ZCL_TIME_TIME_STATUS_DEFAULT_VALUE,
    .time_zone = 3 * 60 * 60,
    .dst_start = ZB_ZCL_TIME_DST_START_DEFAULT_VALUE,
    .dst_end = ZB_ZCL_TIME_DST_END_DEFAULT_VALUE,
    .dst_shift = ZB_ZCL_TIME_DST_SHIFT_DEFAULT_VALUE,
    .standard_time = ZB_ZCL_TIME_STANDARD_TIME_DEFAULT_VALUE,
    .local_time = ZB_ZCL_TIME_LOCAL_TIME_DEFAULT_VALUE,
    .last_set_time = ZB_ZCL_TIME_LAST_SET_TIME_DEFAULT_VALUE,
    .valid_until_time = ZB_ZCL_TIME_VALID_UNTIL_TIME_DEFAULT_VALUE,
};

/* AirWick control cluster backing values. */
static zb_uint8_t ctrl_mode;
static zb_uint16_t ctrl_auto_interval_min;
static zb_uint8_t ctrl_schedule_days;
static zb_uint16_t ctrl_schedule_start_min;
static zb_uint16_t ctrl_schedule_end_min;
static zb_uint16_t ctrl_schedule_interval_min;
static zb_int16_t ctrl_timezone_min;
static zb_uint32_t ctrl_spray_count;
static zb_uint8_t ctrl_last_reason;
static zb_uint32_t ctrl_last_time = AIRWICK_TIME_INVALID;
static zb_uint32_t ctrl_next_time = AIRWICK_TIME_INVALID;
static zb_bool_t ctrl_time_valid = ZB_FALSE;
static zb_uint8_t ctrl_physical_mode = 0xff; /* selector is not fitted yet */
static zb_bool_t ctrl_reset_counter = ZB_FALSE;
static zb_uint8_t ctrl_settings_version = 2;
static zb_uint32_t ctrl_sync_time;
static zb_uint16_t ctrl_battery_mv;
static zb_uint16_t ctrl_spray_duration_ms = SPRAY_PULSE_DEFAULT_MS;
static zb_bool_t ctrl_program_enabled[AIRWICK_PROGRAM_SLOTS];
static zb_uint8_t ctrl_program_days[AIRWICK_PROGRAM_SLOTS];
static zb_uint16_t ctrl_program_start[AIRWICK_PROGRAM_SLOTS];
static zb_uint16_t ctrl_program_end[AIRWICK_PROGRAM_SLOTS];
static zb_uint16_t ctrl_program_interval[AIRWICK_PROGRAM_SLOTS];

ZB_ZCL_START_DECLARE_ATTRIB_LIST_CLUSTER_REVISION(basic_attrs, ZB_ZCL_BASIC)
    ZB_ZCL_SET_ATTR_DESC(ZB_ZCL_ATTR_BASIC_ZCL_VERSION_ID, &zcl_version)
    ZB_ZCL_SET_ATTR_DESC(ZB_ZCL_ATTR_BASIC_APPLICATION_VERSION_ID, &app_version)
    ZB_ZCL_SET_ATTR_DESC(ZB_ZCL_ATTR_BASIC_POWER_SOURCE_ID, &power_source)
    ZB_ZCL_SET_ATTR_DESC(ZB_ZCL_ATTR_BASIC_MANUFACTURER_NAME_ID, manufacturer)
    ZB_ZCL_SET_ATTR_DESC(ZB_ZCL_ATTR_BASIC_MODEL_IDENTIFIER_ID, model)
    ZB_ZCL_SET_ATTR_DESC(ZB_ZCL_ATTR_BASIC_SW_BUILD_ID, build_id)
ZB_ZCL_FINISH_DECLARE_ATTRIB_LIST;

ZB_ZCL_DECLARE_IDENTIFY_ATTRIB_LIST(identify_attrs, &identify_time);

ZB_ZCL_START_DECLARE_ATTRIB_LIST_CLUSTER_REVISION(on_off_attrs, ZB_ZCL_ON_OFF)
    ZB_SET_ATTR_DESCR_WITH_ZB_ZCL_ATTR_ON_OFF_ON_OFF_ID(&on_off),
    ZB_SET_ATTR_DESCR_WITH_ZB_ZCL_ATTR_ON_OFF_START_UP_ON_OFF(&startup_on_off),
ZB_ZCL_FINISH_DECLARE_ATTRIB_LIST;

ZB_ZCL_START_DECLARE_ATTRIB_LIST_CLUSTER_REVISION(power_attrs, ZB_ZCL_POWER_CONFIG)
    ZB_SET_ATTR_DESCR_WITH_ZB_ZCL_ATTR_POWER_CONFIG_BATTERY_VOLTAGE_ID(&battery_voltage, ),
    ZB_SET_ATTR_DESCR_WITH_ZB_ZCL_ATTR_POWER_CONFIG_BATTERY_PERCENTAGE_REMAINING_ID(
        &battery_percentage_remaining, ),
ZB_ZCL_FINISH_DECLARE_ATTRIB_LIST;

ZB_ZCL_DECLARE_TIME_ATTR_LIST(time_attrs, time_cluster);

ZB_ZCL_START_DECLARE_ATTRIB_LIST_CLUSTER_REVISION(control_attrs, AIRWICK_CTRL)
    { AW_ATTR_MODE, ZB_ZCL_ATTR_TYPE_8BIT_ENUM, ZB_ZCL_ATTR_ACCESS_READ_WRITE | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_mode },
    { AW_ATTR_AUTO_INTERVAL_MIN, ZB_ZCL_ATTR_TYPE_U16, ZB_ZCL_ATTR_ACCESS_READ_WRITE | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_auto_interval_min },
    { AW_ATTR_SCHEDULE_DAYS, ZB_ZCL_ATTR_TYPE_U8, ZB_ZCL_ATTR_ACCESS_READ_WRITE | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_schedule_days },
    { AW_ATTR_SCHEDULE_START_MIN, ZB_ZCL_ATTR_TYPE_U16, ZB_ZCL_ATTR_ACCESS_READ_WRITE | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_schedule_start_min },
    { AW_ATTR_SCHEDULE_END_MIN, ZB_ZCL_ATTR_TYPE_U16, ZB_ZCL_ATTR_ACCESS_READ_WRITE | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_schedule_end_min },
    { AW_ATTR_SCHEDULE_INTERVAL_MIN, ZB_ZCL_ATTR_TYPE_U16, ZB_ZCL_ATTR_ACCESS_READ_WRITE | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_schedule_interval_min },
    { AW_ATTR_TIMEZONE_MIN, ZB_ZCL_ATTR_TYPE_S16, ZB_ZCL_ATTR_ACCESS_READ_WRITE | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_timezone_min },
    { AW_ATTR_SPRAY_COUNT, ZB_ZCL_ATTR_TYPE_U32, ZB_ZCL_ATTR_ACCESS_READ_ONLY | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_spray_count },
    { AW_ATTR_LAST_SPRAY_REASON, ZB_ZCL_ATTR_TYPE_U8, ZB_ZCL_ATTR_ACCESS_READ_ONLY | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_last_reason },
    { AW_ATTR_LAST_SPRAY_TIME, ZB_ZCL_ATTR_TYPE_UTC_TIME, ZB_ZCL_ATTR_ACCESS_READ_ONLY | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_last_time },
    { AW_ATTR_NEXT_SPRAY_TIME, ZB_ZCL_ATTR_TYPE_UTC_TIME, ZB_ZCL_ATTR_ACCESS_READ_ONLY | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_next_time },
    { AW_ATTR_TIME_VALID, ZB_ZCL_ATTR_TYPE_BOOL, ZB_ZCL_ATTR_ACCESS_READ_ONLY | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_time_valid },
    { AW_ATTR_PHYSICAL_MODE, ZB_ZCL_ATTR_TYPE_U8, ZB_ZCL_ATTR_ACCESS_READ_ONLY | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_physical_mode },
    { AW_ATTR_RESET_COUNTER, ZB_ZCL_ATTR_TYPE_BOOL, ZB_ZCL_ATTR_ACCESS_READ_WRITE | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_reset_counter },
    { AW_ATTR_SETTINGS_VERSION, ZB_ZCL_ATTR_TYPE_U8, ZB_ZCL_ATTR_ACCESS_READ_ONLY,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_settings_version },
    { AW_ATTR_SYNC_TIME, ZB_ZCL_ATTR_TYPE_U32, ZB_ZCL_ATTR_ACCESS_READ_WRITE,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_sync_time },
    { AW_ATTR_BATTERY_MV, ZB_ZCL_ATTR_TYPE_U16, ZB_ZCL_ATTR_ACCESS_READ_ONLY | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_battery_mv },
    { AW_ATTR_SPRAY_DURATION_MS, ZB_ZCL_ATTR_TYPE_U16, ZB_ZCL_ATTR_ACCESS_READ_WRITE | ZB_ZCL_ATTR_ACCESS_REPORTING,
      ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_spray_duration_ms },

    { 0x0020, ZB_ZCL_ATTR_TYPE_BOOL, ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_enabled[0] },
    { 0x0021, ZB_ZCL_ATTR_TYPE_U8,   ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_days[0] },
    { 0x0022, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_start[0] },
    { 0x0023, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_end[0] },
    { 0x0024, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_interval[0] },
    { 0x0028, ZB_ZCL_ATTR_TYPE_BOOL, ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_enabled[1] },
    { 0x0029, ZB_ZCL_ATTR_TYPE_U8,   ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_days[1] },
    { 0x002A, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_start[1] },
    { 0x002B, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_end[1] },
    { 0x002C, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_interval[1] },
    { 0x0030, ZB_ZCL_ATTR_TYPE_BOOL, ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_enabled[2] },
    { 0x0031, ZB_ZCL_ATTR_TYPE_U8,   ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_days[2] },
    { 0x0032, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_start[2] },
    { 0x0033, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_end[2] },
    { 0x0034, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_interval[2] },
    { 0x0038, ZB_ZCL_ATTR_TYPE_BOOL, ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_enabled[3] },
    { 0x0039, ZB_ZCL_ATTR_TYPE_U8,   ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_days[3] },
    { 0x003A, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_start[3] },
    { 0x003B, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_end[3] },
    { 0x003C, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_interval[3] },
    { 0x0040, ZB_ZCL_ATTR_TYPE_BOOL, ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_enabled[4] },
    { 0x0041, ZB_ZCL_ATTR_TYPE_U8,   ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_days[4] },
    { 0x0042, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_start[4] },
    { 0x0043, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_end[4] },
    { 0x0044, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_interval[4] },
    { 0x0048, ZB_ZCL_ATTR_TYPE_BOOL, ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_enabled[5] },
    { 0x0049, ZB_ZCL_ATTR_TYPE_U8,   ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_days[5] },
    { 0x004A, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_start[5] },
    { 0x004B, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_end[5] },
    { 0x004C, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_interval[5] },
    { 0x0050, ZB_ZCL_ATTR_TYPE_BOOL, ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_enabled[6] },
    { 0x0051, ZB_ZCL_ATTR_TYPE_U8,   ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_days[6] },
    { 0x0052, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_start[6] },
    { 0x0053, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_end[6] },
    { 0x0054, ZB_ZCL_ATTR_TYPE_U16,  ZB_ZCL_ATTR_ACCESS_READ_WRITE, ZB_ZCL_NON_MANUFACTURER_SPECIFIC, (void *)&ctrl_program_interval[6] },
ZB_ZCL_FINISH_DECLARE_ATTRIB_LIST;

ZBOSS_DEVICE_DECLARE_REPORTING_CTX(reporting_info, 36);

static zb_zcl_cluster_desc_t clusters[] = {
    ZB_ZCL_CLUSTER_DESC(ZB_ZCL_CLUSTER_ID_BASIC,
        ZB_ZCL_ARRAY_SIZE(basic_attrs, zb_zcl_attr_t), basic_attrs,
        ZB_ZCL_CLUSTER_SERVER_ROLE, ZB_ZCL_MANUF_CODE_INVALID),
    ZB_ZCL_CLUSTER_DESC(ZB_ZCL_CLUSTER_ID_IDENTIFY,
        ZB_ZCL_ARRAY_SIZE(identify_attrs, zb_zcl_attr_t), identify_attrs,
        ZB_ZCL_CLUSTER_SERVER_ROLE, ZB_ZCL_MANUF_CODE_INVALID),
    ZB_ZCL_CLUSTER_DESC(ZB_ZCL_CLUSTER_ID_ON_OFF,
        ZB_ZCL_ARRAY_SIZE(on_off_attrs, zb_zcl_attr_t), on_off_attrs,
        ZB_ZCL_CLUSTER_SERVER_ROLE, ZB_ZCL_MANUF_CODE_INVALID),
    ZB_ZCL_CLUSTER_DESC(ZB_ZCL_CLUSTER_ID_POWER_CONFIG,
        ZB_ZCL_ARRAY_SIZE(power_attrs, zb_zcl_attr_t), power_attrs,
        ZB_ZCL_CLUSTER_SERVER_ROLE, ZB_ZCL_MANUF_CODE_INVALID),
    ZB_ZCL_CLUSTER_DESC(ZB_ZCL_CLUSTER_ID_TIME,
        ZB_ZCL_ARRAY_SIZE(time_attrs, zb_zcl_attr_t), time_attrs,
        ZB_ZCL_CLUSTER_SERVER_ROLE, ZB_ZCL_MANUF_CODE_INVALID),
    {
        .cluster_id = AIRWICK_CTRL,
        .attr_count = ZB_ZCL_ARRAY_SIZE(control_attrs, zb_zcl_attr_t),
        .attr_desc_list = control_attrs,
        .role_mask = ZB_ZCL_CLUSTER_SERVER_ROLE,
        .manuf_code = ZB_ZCL_MANUF_CODE_INVALID,
        .cluster_init = (zb_zcl_cluster_init_t)NULL,
    },
};

ZB_DECLARE_SIMPLE_DESC(6, 0);
static ZB_AF_SIMPLE_DESC_TYPE(6, 0) simple_desc = {
    AIRWICK_ENDPOINT, ZB_AF_HA_PROFILE_ID,
    0x0108,
    0, 0, 6, 0,
    {ZB_ZCL_CLUSTER_ID_BASIC, ZB_ZCL_CLUSTER_ID_IDENTIFY,
     ZB_ZCL_CLUSTER_ID_ON_OFF, ZB_ZCL_CLUSTER_ID_POWER_CONFIG,
     ZB_ZCL_CLUSTER_ID_TIME, AIRWICK_CTRL}
};

ZB_AF_DECLARE_ENDPOINT_DESC(airwick_ep, AIRWICK_ENDPOINT, ZB_AF_HA_PROFILE_ID,
    0, NULL, ZB_ZCL_ARRAY_SIZE(clusters, zb_zcl_cluster_desc_t), clusters,
    (zb_af_simple_desc_1_1_t *)&simple_desc,
    20, reporting_info, 0, NULL);
ZBOSS_DECLARE_DEVICE_CTX_1_EP(airwick_ctx, airwick_ep);

static bool clock_now(uint32_t *utc_out)
{
    k_spinlock_key_t key = k_spin_lock(&clock_lock);
    if (!wall_clock_valid) {
        k_spin_unlock(&clock_lock, key);
        return false;
    }
    int64_t elapsed_ms = k_uptime_get() - clock_anchor_uptime_ms;
    uint64_t value = (uint64_t)clock_anchor_utc + (uint64_t)(elapsed_ms > 0 ? elapsed_ms / 1000 : 0);
    if (value > UINT32_MAX) {
        k_spin_unlock(&clock_lock, key);
        return false;
    }
    *utc_out = (uint32_t)value;
    k_spin_unlock(&clock_lock, key);
    return true;
}

static void clock_set(uint32_t utc)
{
    k_spinlock_key_t key = k_spin_lock(&clock_lock);
    clock_anchor_utc = utc;
    clock_anchor_uptime_ms = k_uptime_get();
    wall_clock_valid = true;
    k_spin_unlock(&clock_lock, key);
}

/* A saved UTC checkpoint cannot reconstruct elapsed time across power loss.
 * During a powered Zigbee outage clock_now() keeps ticking via k_uptime_get().
 * On reboot the wall clock is deliberately untrusted until the next time sync.
 * The existing NVS checkpoint key is retained for downgrade compatibility. */
static void clock_checkpoint_save_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    if (atomic_get(&factory_reset_active) != 0) {
        return;
    }

    uint32_t now;
    if (!clock_now(&now)) {
        return;
    }

    struct airwick_clock_checkpoint cp = {
        .magic = CLOCK_MAGIC,
        .utc = now,
    };
    (void)settings_save_one(CLOCK_KEY, &cp, sizeof(cp));
}

static uint32_t time_sync_retry_delay_ms(void)
{
    if (atomic_get(&clock_network_synced) != 0) {
        return TIME_SYNC_PERIOD_MS;
    }
    if (atomic_get(&time_sync_attempts) < 3) {
        return TIME_SYNC_RETRY_FAST_MS;
    }
    if (atomic_get(&time_sync_attempts) < 6) {
        return TIME_SYNC_RETRY_MEDIUM_MS;
    }
    return TIME_SYNC_RETRY_SLOW_MS;
}

static int64_t auto_deadline_get(void)
{
    k_spinlock_key_t key = k_spin_lock(&auto_lock);
    int64_t value = auto_deadline_ms;
    k_spin_unlock(&auto_lock, key);
    return value;
}

static void auto_deadline_set(int64_t value)
{
    k_spinlock_key_t key = k_spin_lock(&auto_lock);
    auto_deadline_ms = value;
    k_spin_unlock(&auto_lock, key);
}

static void schedule_stats_save(void)
{
    (void)k_work_reschedule(&stats_save_work, K_NO_WAIT);
}

static void schedule_control_report(void)
{
    (void)k_work_submit(&control_report_work);
}

static void mark_control_attr(zb_uint16_t attr)
{
    zb_zcl_mark_attr_for_reporting(AIRWICK_ENDPOINT, AIRWICK_CTRL,
        ZB_ZCL_CLUSTER_SERVER_ROLE, attr);
}

#define AIRWICK_COORDINATOR_SHORT_ADDR 0x0000U
#define AIRWICK_COORDINATOR_ENDPOINT   1U

/*
 * v0.20 reliability path:
 * ZBOSS' configured attribute-reporting table is kept as the standards-compliant
 * background/fallback mechanism, but field testing showed that local attribute
 * changes could remain cached until a coordinator Read Attributes request.
 *
 * Therefore local runtime state is also pushed as an explicit standard ZCL
 * Report Attributes frame to the coordinator.  This does not poll and does not
 * keep the sleepy end device awake; it only transmits when the existing runtime
 * refresh path already runs (selector change, spray, scheduler update, retry).
 */
static zb_uint8_t *airwick_report_start(zb_bufid_t bufid)
{
    zb_uint8_t *ptr = ZB_ZCL_START_PACKET(bufid);
    ZB_ZCL_CONSTRUCT_GENERAL_COMMAND_REQ_FRAME_CONTROL_A(
        ptr,
        ZB_ZCL_FRAME_DIRECTION_TO_CLI,
        ZB_ZCL_NOT_MANUFACTURER_SPECIFIC,
        ZB_ZCL_DISABLE_DEFAULT_RESPONSE);
    ZB_ZCL_CONSTRUCT_COMMAND_HEADER(ptr, ZB_ZCL_GET_SEQ_NUM(), ZB_ZCL_CMD_REPORT_ATTRIB);
    return ptr;
}

static void airwick_report_send(zb_bufid_t bufid, zb_uint8_t *ptr, zb_uint16_t cluster_id)
{
    zb_addr_u dst_addr;
    ZB_MEMSET(&dst_addr, 0, sizeof(dst_addr));
    dst_addr.addr_short = AIRWICK_COORDINATOR_SHORT_ADDR;

    zb_ret_t rc = zb_zcl_finish_and_send_packet(
        bufid,
        ptr,
        &dst_addr,
        ZB_APS_ADDR_MODE_16_ENDP_PRESENT,
        AIRWICK_COORDINATOR_ENDPOINT,
        AIRWICK_ENDPOINT,
        ZB_AF_HA_PROFILE_ID,
        cluster_id,
        NULL);

    if (rc != RET_OK) {
        zb_buf_free(bufid);
    }
}

static void airwick_push_control_report_buf(zb_uint8_t bufid)
{
    if (bufid == 0U) {
        return;
    }
    if (atomic_get(&network_joined) == 0) {
        zb_buf_free(bufid);
        return;
    }

    zb_uint8_t *ptr = airwick_report_start(bufid);

    ZB_ZCL_PACKET_PUT_DATA16_VAL(ptr, AW_ATTR_MODE);
    ZB_ZCL_PACKET_PUT_DATA8(ptr, ZB_ZCL_ATTR_TYPE_8BIT_ENUM);
    ZB_ZCL_PACKET_PUT_DATA8(ptr, ctrl_mode);

    /* Append one attribute to the EXISTING event report, no new packet or timer. */
    ZB_ZCL_PACKET_PUT_DATA16_VAL(ptr, AW_ATTR_SPRAY_DURATION_MS);
    ZB_ZCL_PACKET_PUT_DATA8(ptr, ZB_ZCL_ATTR_TYPE_U16);
    ZB_ZCL_PACKET_PUT_DATA16_VAL(ptr, ctrl_spray_duration_ms);

    ZB_ZCL_PACKET_PUT_DATA16_VAL(ptr, AW_ATTR_PHYSICAL_MODE);
    ZB_ZCL_PACKET_PUT_DATA8(ptr, ZB_ZCL_ATTR_TYPE_U8);
    ZB_ZCL_PACKET_PUT_DATA8(ptr, ctrl_physical_mode);

    ZB_ZCL_PACKET_PUT_DATA16_VAL(ptr, AW_ATTR_SPRAY_COUNT);
    ZB_ZCL_PACKET_PUT_DATA8(ptr, ZB_ZCL_ATTR_TYPE_U32);
    ZB_ZCL_PACKET_PUT_DATA32_VAL(ptr, ctrl_spray_count);

    ZB_ZCL_PACKET_PUT_DATA16_VAL(ptr, AW_ATTR_LAST_SPRAY_REASON);
    ZB_ZCL_PACKET_PUT_DATA8(ptr, ZB_ZCL_ATTR_TYPE_U8);
    ZB_ZCL_PACKET_PUT_DATA8(ptr, ctrl_last_reason);

    ZB_ZCL_PACKET_PUT_DATA16_VAL(ptr, AW_ATTR_LAST_SPRAY_TIME);
    ZB_ZCL_PACKET_PUT_DATA8(ptr, ZB_ZCL_ATTR_TYPE_UTC_TIME);
    ZB_ZCL_PACKET_PUT_DATA32_VAL(ptr, ctrl_last_time);

    ZB_ZCL_PACKET_PUT_DATA16_VAL(ptr, AW_ATTR_NEXT_SPRAY_TIME);
    ZB_ZCL_PACKET_PUT_DATA8(ptr, ZB_ZCL_ATTR_TYPE_UTC_TIME);
    ZB_ZCL_PACKET_PUT_DATA32_VAL(ptr, ctrl_next_time);

    ZB_ZCL_PACKET_PUT_DATA16_VAL(ptr, AW_ATTR_TIME_VALID);
    ZB_ZCL_PACKET_PUT_DATA8(ptr, ZB_ZCL_ATTR_TYPE_BOOL);
    ZB_ZCL_PACKET_PUT_DATA8(ptr, ctrl_time_valid);

    if (ctrl_battery_mv != 0U) {
        ZB_ZCL_PACKET_PUT_DATA16_VAL(ptr, AW_ATTR_BATTERY_MV);
        ZB_ZCL_PACKET_PUT_DATA8(ptr, ZB_ZCL_ATTR_TYPE_U16);
        ZB_ZCL_PACKET_PUT_DATA16_VAL(ptr, ctrl_battery_mv);
    }

    airwick_report_send(bufid, ptr, AIRWICK_CTRL);
}

static void airwick_push_onoff_report_buf(zb_uint8_t bufid)
{
    if (bufid == 0U) {
        return;
    }
    if (atomic_get(&network_joined) == 0) {
        zb_buf_free(bufid);
        return;
    }

    zb_uint8_t *ptr = airwick_report_start(bufid);
    ZB_ZCL_PACKET_PUT_DATA16_VAL(ptr, ZB_ZCL_ATTR_ON_OFF_ON_OFF_ID);
    ZB_ZCL_PACKET_PUT_DATA8(ptr, ZB_ZCL_ATTR_TYPE_BOOL);
    ZB_ZCL_PACKET_PUT_DATA8(ptr, on_off);
    airwick_report_send(bufid, ptr, ZB_ZCL_CLUSTER_ID_ON_OFF);
}

static void airwick_push_runtime_reports_zboss(void)
{
    if (atomic_get(&network_joined) == 0) {
        return;
    }
    (void)zb_buf_get_out_delayed(airwick_push_control_report_buf);
    (void)zb_buf_get_out_delayed(airwick_push_onoff_report_buf);
}

static void control_runtime_refresh_zboss(zb_uint8_t unused)
{
    ARG_UNUSED(unused);
    uint32_t now;
    bool valid = clock_now(&now);

    zb_uint8_t mode = cfg->mode;
    zb_uint8_t physical_mode = ctrl_physical_mode;
    zb_uint16_t battery_mv = ctrl_battery_mv;
    zb_uint32_t count = stats->spray_count;
    zb_uint8_t reason = stats->last_spray_reason;
    zb_uint32_t last_time = stats->last_spray_time;
    zb_uint32_t next_time = stats->next_spray_time;
    zb_bool_t time_valid = atomic_get(&clock_network_synced) != 0 ? ZB_TRUE : ZB_FALSE;

    ZB_ZCL_SET_ATTRIBUTE(AIRWICK_ENDPOINT, AIRWICK_CTRL,
        ZB_ZCL_CLUSTER_SERVER_ROLE, AW_ATTR_MODE, &mode, ZB_FALSE);
    ZB_ZCL_SET_ATTRIBUTE(AIRWICK_ENDPOINT, AIRWICK_CTRL,
        ZB_ZCL_CLUSTER_SERVER_ROLE, AW_ATTR_PHYSICAL_MODE, &physical_mode, ZB_FALSE);
    if (battery_mv != 0U) {
        ZB_ZCL_SET_ATTRIBUTE(AIRWICK_ENDPOINT, AIRWICK_CTRL,
            ZB_ZCL_CLUSTER_SERVER_ROLE, AW_ATTR_BATTERY_MV,
            (zb_uint8_t *)&battery_mv, ZB_FALSE);
    }
    ZB_ZCL_SET_ATTRIBUTE(AIRWICK_ENDPOINT, AIRWICK_CTRL,
        ZB_ZCL_CLUSTER_SERVER_ROLE, AW_ATTR_SPRAY_COUNT, (zb_uint8_t *)&count, ZB_FALSE);
    ZB_ZCL_SET_ATTRIBUTE(AIRWICK_ENDPOINT, AIRWICK_CTRL,
        ZB_ZCL_CLUSTER_SERVER_ROLE, AW_ATTR_LAST_SPRAY_REASON, &reason, ZB_FALSE);
    ZB_ZCL_SET_ATTRIBUTE(AIRWICK_ENDPOINT, AIRWICK_CTRL,
        ZB_ZCL_CLUSTER_SERVER_ROLE, AW_ATTR_LAST_SPRAY_TIME, (zb_uint8_t *)&last_time, ZB_FALSE);
    ZB_ZCL_SET_ATTRIBUTE(AIRWICK_ENDPOINT, AIRWICK_CTRL,
        ZB_ZCL_CLUSTER_SERVER_ROLE, AW_ATTR_NEXT_SPRAY_TIME, (zb_uint8_t *)&next_time, ZB_FALSE);
    ZB_ZCL_SET_ATTRIBUTE(AIRWICK_ENDPOINT, AIRWICK_CTRL,
        ZB_ZCL_CLUSTER_SERVER_ROLE, AW_ATTR_TIME_VALID, (zb_uint8_t *)&time_valid, ZB_FALSE);

    /* Force a runtime-state report even when the value itself did not change
     * during this particular callback. This also retries a packet that may have
     * been lost while the sleepy child was transitioning between local events. */
    mark_control_attr(AW_ATTR_MODE);
    mark_control_attr(AW_ATTR_PHYSICAL_MODE);
    if (battery_mv != 0U) {
        mark_control_attr(AW_ATTR_BATTERY_MV);
    }
    mark_control_attr(AW_ATTR_SPRAY_COUNT);
    mark_control_attr(AW_ATTR_LAST_SPRAY_REASON);
    mark_control_attr(AW_ATTR_LAST_SPRAY_TIME);
    mark_control_attr(AW_ATTR_NEXT_SPRAY_TIME);
    mark_control_attr(AW_ATTR_TIME_VALID);
    zb_zcl_mark_attr_for_reporting(AIRWICK_ENDPOINT,
        ZB_ZCL_CLUSTER_ID_ON_OFF,
        ZB_ZCL_CLUSTER_SERVER_ROLE,
        ZB_ZCL_ATTR_ON_OFF_ON_OFF_ID);

    /* Immediate push for local state changes; automatic reporting remains fallback. */
    airwick_push_runtime_reports_zboss();

    if (valid) {
        time_cluster.time = now;
        time_cluster.time_status = atomic_get(&clock_network_synced) != 0 ? 0x02 : 0x00;
        time_cluster.time_zone = (zb_int32_t)cfg->timezone_minutes * 60;
        time_cluster.standard_time = now + time_cluster.time_zone;
        time_cluster.local_time = time_cluster.standard_time;
    }
}

static void control_report_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    (void)ZB_SCHEDULE_APP_CALLBACK(control_runtime_refresh_zboss, 0);
}

static void state_report_retry_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    schedule_control_report();
}

static void schedule_state_report_retry(void)
{
    (void)k_work_reschedule(&state_report_retry_work, K_MSEC(STATE_REPORT_RETRY_MS));
}

static void control_from_persistent_state(void)
{
    ctrl_mode = cfg->mode;
    ctrl_auto_interval_min = cfg->auto_interval_minute;
    ctrl_spray_duration_ms = spray_duration_ms();
    ctrl_schedule_days = cfg->schedule_days_mask;
    ctrl_schedule_start_min = cfg->schedule_start_minute;
    ctrl_schedule_end_min = cfg->schedule_end_minute;
    ctrl_schedule_interval_min = cfg->schedule_interval_minute;
    ctrl_timezone_min = cfg->timezone_minutes;
    ctrl_spray_count = stats->spray_count;
    ctrl_last_reason = stats->last_spray_reason;
    ctrl_last_time = stats->last_spray_time;
    ctrl_next_time = stats->next_spray_time;
    startup_on_off = cfg->startup_on_off;
    time_cluster.time_zone = (zb_int32_t)cfg->timezone_minutes * 60;

    for (unsigned int i = 0; i < AIRWICK_PROGRAM_SLOTS; i++) {
        ctrl_program_enabled[i] = cfg->program[i].enabled ? ZB_TRUE : ZB_FALSE;
        ctrl_program_days[i] = cfg->program[i].days_mask;
        ctrl_program_start[i] = cfg->program[i].start_minute;
        ctrl_program_end[i] = cfg->program[i].end_minute;
        ctrl_program_interval[i] = cfg->program[i].interval_minute;
    }
}

static void status_led_refresh(void)
{
#if STATUS_LED_OUTPUT_ENABLED
    if (!gpio_is_ready_dt(&status_led)) {
        return;
    }
    bool on = (atomic_get(&pulse_active) != 0) ||
              (atomic_get(&identify_led_on) != 0) ||
              (atomic_get(&pairing_led_on) != 0);
    (void)gpio_pin_set_dt(&status_led, on ? 1 : 0);
#else
    /* Production battery build: keep the board LED permanently off.
     * Pairing/Identify state machines stay intact; only the LED load is removed. */
    ARG_UNUSED(status_led);
#endif
}

static void motor_physical_set(bool active)
{
    (void)gpio_pin_set_dt(&motor_out, active ? 1 : 0);
    status_led_refresh();
}

static void set_reported_state(zb_bool_t state)
{
    zb_bool_t value = state ? ZB_TRUE : ZB_FALSE;
    ZB_ZCL_SET_ATTRIBUTE(AIRWICK_ENDPOINT,
        ZB_ZCL_CLUSTER_ID_ON_OFF,
        ZB_ZCL_CLUSTER_SERVER_ROLE,
        ZB_ZCL_ATTR_ON_OFF_ON_OFF_ID,
        (zb_uint8_t *)&value, ZB_FALSE);
}

static void motor_state_sync_zboss(zb_uint8_t unused)
{
    ARG_UNUSED(unused);
    set_reported_state(atomic_get(&pulse_active) != 0 ? ZB_TRUE : ZB_FALSE);
    schedule_control_report();
    schedule_state_report_retry();
}

static void finish_spray_zboss(zb_uint8_t unused)
{
    ARG_UNUSED(unused);
    set_reported_state(ZB_FALSE);
    schedule_control_report();
    schedule_state_report_retry();
}

static void motor_state_sync_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    zb_ret_t rc = ZB_SCHEDULE_APP_CALLBACK(motor_state_sync_zboss, 0);
    if (rc != RET_OK) {
        (void)k_work_reschedule(&motor_state_sync_work, K_MSEC(50));
    }
}

static void motor_cutoff_expiry(struct k_timer *timer)
{
    ARG_UNUSED(timer);
    atomic_clear(&pulse_active);
    (void)gpio_pin_set_dt(&motor_out, 0);
    status_led_refresh();
    (void)k_work_reschedule(&motor_state_sync_work, K_NO_WAIT);
}

static void motor_force_off_local(void)
{
    k_timer_stop(&motor_cutoff_timer);
    atomic_clear(&pulse_active);
    motor_physical_set(false);
    (void)k_work_reschedule(&motor_state_sync_work, K_NO_WAIT);
}

static void motor_force_off_zboss(void)
{
    k_timer_stop(&motor_cutoff_timer);
    atomic_clear(&pulse_active);
    motor_physical_set(false);
    set_reported_state(ZB_FALSE);
}

static bool request_spray(enum spray_reason reason)
{
    int64_t now_ms = k_uptime_get();
    if (atomic_get(&factory_reset_active) != 0 ||
        (now_ms - last_spray_ms) < SPRAY_LOCKOUT_MS) {
        return false;
    }
    /* Two callers may arrive from ZBOSS and the local-button workqueue.
     * Reserve the one allowed pulse BEFORE touching the counter or timer. */
    if (!atomic_cas(&pulse_active, 0, 1)) {
        return false;
    }

    last_spray_ms = now_ms;
    spray_count++;
    last_spray_reason = reason;

    stats->spray_count = spray_count;
    stats->last_spray_reason = (uint8_t)reason;
    uint32_t now_utc;
    stats->last_spray_time = clock_now(&now_utc) ? now_utc : AIRWICK_TIME_INVALID;

    /* Manual/button/Zigbee sprays never move the autonomous cadence.
     * AUTO advances its own deadline in scheduler_work_handler; SCHEDULE and
     * PROGRAMMABLE are anchored to their configured wall-clock windows. */
    schedule_stats_save();
    schedule_control_report();

    motor_physical_set(true);
    (void)k_work_reschedule(&motor_state_sync_work, K_NO_WAIT);
    /* Latch configured pulse once at start; changing it never extends an active pulse. */
    k_timer_start(&motor_cutoff_timer, K_MSEC(spray_duration_ms()), K_NO_WAIT);
    return true;
}

static void identify_stop(void)
{
    (void)k_work_cancel_delayable(&identify_work);
    identify_phase = 0;
    atomic_clear(&identify_led_on);
    status_led_refresh();
}

static void identify_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    if (k_uptime_get() >= identify_deadline_ms) {
        identify_phase = 0;
        atomic_clear(&identify_led_on);
        status_led_refresh();
        return;
    }

    static const uint16_t delays_ms[4] = {120, 120, 120, 760};
    static const uint8_t led_states[4] = {1, 0, 1, 0};
    atomic_set(&identify_led_on, led_states[identify_phase]);
    status_led_refresh();
    uint16_t delay = delays_ms[identify_phase];
    identify_phase = (identify_phase + 1U) & 0x03U;
    (void)k_work_reschedule(&identify_work, K_MSEC(delay));
}

static void identify_start(zb_uint16_t seconds)
{
    identify_stop();
    if (seconds == 0U) {
        return;
    }
    if (seconds > IDENTIFY_MAX_SECONDS) {
        seconds = IDENTIFY_MAX_SECONDS;
    }
    identify_deadline_ms = k_uptime_get() + ((int64_t)seconds * 1000LL);
    identify_phase = 0;
    (void)k_work_reschedule(&identify_work, K_NO_WAIT);
}

struct battery_curve_point {
    zb_uint16_t mv;
    zb_uint8_t pct_x2;
};

/* 1S Li-ion open-circuit approximation.  Standard ZCL reports 0.5% units.
 * Exact voltage is also exposed independently, so the real discharge trend is visible.
 * The curve can later be calibrated against the actual 14500 cell without changing UI. */
static const struct battery_curve_point battery_curve[] = {
    {4200, 200}, {4180, 196}, {4160, 192}, {4140, 188}, {4120, 184},
    {4100, 180}, {4080, 176}, {4060, 171}, {4040, 166}, {4020, 160},
    {4000, 154}, {3980, 148}, {3960, 142}, {3940, 135}, {3920, 128},
    {3900, 120}, {3880, 112}, {3860, 104}, {3840, 96},  {3820, 88},
    {3800, 80},  {3780, 72},  {3760, 64},  {3740, 56},  {3720, 48},
    {3700, 40},  {3680, 32},  {3660, 25},  {3640, 19},  {3620, 14},
    {3600, 10},  {3580, 7},   {3560, 5},   {3540, 3},   {3520, 2},
    {3500, 1},   {3400, 0},
};

static zb_uint8_t liion_percent_x2(zb_uint16_t mv)
{
    if (mv >= battery_curve[0].mv) {
        return battery_curve[0].pct_x2;
    }
    for (size_t i = 1; i < ARRAY_SIZE(battery_curve); i++) {
        const struct battery_curve_point *hi = &battery_curve[i - 1];
        const struct battery_curve_point *lo = &battery_curve[i];
        if (mv >= lo->mv) {
            zb_uint32_t span_mv = (zb_uint32_t)hi->mv - lo->mv;
            zb_uint32_t delta_mv = (zb_uint32_t)mv - lo->mv;
            zb_uint32_t span_pct = (zb_uint32_t)hi->pct_x2 - lo->pct_x2;
            return (zb_uint8_t)(lo->pct_x2 +
                (delta_mv * span_pct + span_mv / 2U) / span_mv);
        }
    }
    return 0U;
}

static void battery_set_invalid(void)
{
    ctrl_battery_mv = 0U;
    zb_uint8_t invalid_voltage = ZB_ZCL_POWER_CONFIG_BATTERY_VOLTAGE_INVALID;
    zb_uint8_t invalid_percent = ZB_ZCL_POWER_CONFIG_BATTERY_REMAINING_UNKNOWN;
    ZB_ZCL_SET_ATTRIBUTE(AIRWICK_ENDPOINT, ZB_ZCL_CLUSTER_ID_POWER_CONFIG,
        ZB_ZCL_CLUSTER_SERVER_ROLE,
        ZB_ZCL_ATTR_POWER_CONFIG_BATTERY_VOLTAGE_ID,
        &invalid_voltage, ZB_FALSE);
    ZB_ZCL_SET_ATTRIBUTE(AIRWICK_ENDPOINT, ZB_ZCL_CLUSTER_ID_POWER_CONFIG,
        ZB_ZCL_CLUSTER_SERVER_ROLE,
        ZB_ZCL_ATTR_POWER_CONFIG_BATTERY_PERCENTAGE_REMAINING_ID,
        &invalid_percent, ZB_FALSE);
}

static bool battery_read_mv(zb_uint16_t *full_mv_out)
{
    int64_t sum_mv = 0;
    for (uint8_t i = 0; i < BATTERY_SAMPLES; i++) {
        int16_t raw = 0;
        struct adc_sequence sequence = {0};
        int rc = adc_sequence_init_dt(&battery_adc, &sequence);
        if (rc != 0) return false;
        sequence.buffer = &raw;
        sequence.buffer_size = sizeof(raw);
        rc = adc_read(battery_adc.dev, &sequence);
        if (rc != 0) return false;
        int32_t mv = raw;
        rc = adc_raw_to_millivolts_dt(&battery_adc, &mv);
        if (rc != 0 || mv < 0) return false;
        sum_mv += mv;
    }

    zb_uint32_t adc_mv = (zb_uint32_t)(sum_mv / BATTERY_SAMPLES);
    zb_uint32_t full_mv = adc_mv * BATTERY_DIVIDER_NUM;
    if (full_mv < BATTERY_VALID_MIN_MV || full_mv > BATTERY_VALID_MAX_MV) {
        return false;
    }
    *full_mv_out = (zb_uint16_t)full_mv;
    return true;
}

static void battery_sample(zb_uint8_t unused)
{
    ARG_UNUSED(unused);
    zb_uint16_t full_mv;
    if (battery_read_mv(&full_mv)) {
        zb_uint8_t voltage_100mv =
            (zb_uint8_t)MIN(((zb_uint32_t)full_mv + 50U) / 100U, 254U);
        zb_uint8_t percent_half = liion_percent_x2(full_mv);
        ctrl_battery_mv = full_mv;
        ZB_ZCL_SET_ATTRIBUTE(AIRWICK_ENDPOINT, AIRWICK_CTRL,
            ZB_ZCL_CLUSTER_SERVER_ROLE, AW_ATTR_BATTERY_MV,
            (zb_uint8_t *)&ctrl_battery_mv, ZB_FALSE);
        mark_control_attr(AW_ATTR_BATTERY_MV);
        ZB_ZCL_SET_ATTRIBUTE(AIRWICK_ENDPOINT, ZB_ZCL_CLUSTER_ID_POWER_CONFIG,
            ZB_ZCL_CLUSTER_SERVER_ROLE,
            ZB_ZCL_ATTR_POWER_CONFIG_BATTERY_VOLTAGE_ID,
            &voltage_100mv, ZB_FALSE);
        ZB_ZCL_SET_ATTRIBUTE(AIRWICK_ENDPOINT, ZB_ZCL_CLUSTER_ID_POWER_CONFIG,
            ZB_ZCL_CLUSTER_SERVER_ROLE,
            ZB_ZCL_ATTR_POWER_CONFIG_BATTERY_PERCENTAGE_REMAINING_ID,
            &percent_half, ZB_FALSE);
        /* Keep voltage and percentage synchronized in Z2M. Mark the standard
         * attributes for the existing ZCL reporting engine; no additional
         * forced runtime packet is generated here. */
        zb_zcl_mark_attr_for_reporting(AIRWICK_ENDPOINT,
            ZB_ZCL_CLUSTER_ID_POWER_CONFIG,
            ZB_ZCL_CLUSTER_SERVER_ROLE,
            ZB_ZCL_ATTR_POWER_CONFIG_BATTERY_VOLTAGE_ID);
        zb_zcl_mark_attr_for_reporting(AIRWICK_ENDPOINT,
            ZB_ZCL_CLUSTER_ID_POWER_CONFIG,
            ZB_ZCL_CLUSTER_SERVER_ROLE,
            ZB_ZCL_ATTR_POWER_CONFIG_BATTERY_PERCENTAGE_REMAINING_ID);
    } else {
        battery_set_invalid();
    }
    ZB_ERROR_CHECK(ZB_SCHEDULE_APP_ALARM(battery_sample, 0,
        ZB_MILLISECONDS_TO_BEACON_INTERVAL(BATTERY_SAMPLE_MS)));
}

static void start_battery_sampling(void)
{
    if (battery_alarm_started) return;
    battery_alarm_started = true;
    ZB_ERROR_CHECK(ZB_SCHEDULE_APP_CALLBACK(battery_sample, 0));
}


static bool selector_read_mv(uint16_t *mv_out)
{
    int64_t sum_mv = 0;
    bool ok = true;

    if (gpio_pin_set_dt(&selector_power, 1) != 0) {
        return false;
    }
    k_sleep(K_MSEC(SELECTOR_SETTLE_MS));

    for (uint8_t i = 0; i < SELECTOR_SAMPLES; i++) {
        int16_t raw = 0;
        struct adc_sequence sequence = {0};
        int rc = adc_sequence_init_dt(&selector_adc, &sequence);
        if (rc != 0) {
            ok = false;
            break;
        }
        sequence.buffer = &raw;
        sequence.buffer_size = sizeof(raw);
        rc = adc_read(selector_adc.dev, &sequence);
        if (rc != 0) {
            ok = false;
            break;
        }
        int32_t mv = raw;
        rc = adc_raw_to_millivolts_dt(&selector_adc, &mv);
        if (rc != 0 || mv < 0) {
            ok = false;
            break;
        }
        sum_mv += mv;
    }

    (void)gpio_pin_set_dt(&selector_power, 0);

    if (!ok) {
        return false;
    }

    *mv_out = (uint16_t)(sum_mv / SELECTOR_SAMPLES);
    return true;
}

static uint8_t selector_classify(uint16_t mv)
{
    if (mv <= SELECTOR_OFF_MAX_MV) {
        return AIRWICK_MODE_OFF;
    }
    if (mv >= SELECTOR_PROGRAM_MIN_MV && mv <= SELECTOR_PROGRAM_MAX_MV) {
        return AIRWICK_MODE_PROGRAMMABLE;
    }
    if (mv >= SELECTOR_SCHEDULE_MIN_MV && mv <= SELECTOR_SCHEDULE_MAX_MV) {
        return AIRWICK_MODE_SCHEDULE;
    }
    if (mv >= SELECTOR_AUTO_MIN_MV && mv <= SELECTOR_AUTO_MAX_MV) {
        return AIRWICK_MODE_AUTO;
    }
    return SELECTOR_INVALID;
}

static void selector_apply_local(zb_uint8_t mode)
{
    if (mode > AIRWICK_MODE_PROGRAMMABLE) {
        return;
    }

    selector_applied_mode = mode;
    ctrl_physical_mode = mode;

    if (cfg->mode == mode) {
        schedule_control_report();
        return;
    }

    cfg->mode = mode;

    /* Physical OFF must always work, even if the Zigbee stack is unhealthy. */
    if (mode == AIRWICK_MODE_OFF) {
        motor_force_off_local();
    }

    uint32_t now_utc;
    bool time_valid = clock_now(&now_utc);
    if (mode == AIRWICK_MODE_AUTO) {
        uint32_t full = (uint32_t)cfg->auto_interval_minute * 60U;
        stats->fallback_remaining_sec = full;
        auto_deadline_set(k_uptime_get() + (int64_t)full * 1000LL);
        stats->next_spray_time = time_valid ? now_utc + full : AIRWICK_TIME_INVALID;
    } else {
        auto_deadline_set(-1);
        if (time_valid && (mode == AIRWICK_MODE_SCHEDULE || mode == AIRWICK_MODE_PROGRAMMABLE)) {
            stats->next_spray_time = airwick_schedule_next(cfg, now_utc, stats->last_schedule_token);
        } else {
            stats->next_spray_time = AIRWICK_TIME_INVALID;
        }
    }

    schedule_stats_save();
    schedule_control_report();
    schedule_state_report_retry();
    (void)k_work_reschedule(&config_save_work, K_NO_WAIT);
    (void)k_work_reschedule(&scheduler_work, K_NO_WAIT);
}

static void selector_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);

    uint16_t mv;
    uint8_t mode = SELECTOR_INVALID;
    if (selector_read_mv(&mv)) {
        mode = selector_classify(mv);
    }

    if (mode == SELECTOR_INVALID) {
        selector_candidate_mode = SELECTOR_INVALID;
        selector_candidate_count = 0U;
    } else if (mode != selector_candidate_mode) {
        selector_candidate_mode = mode;
        selector_candidate_count = 1U;
    } else if (selector_candidate_count < SELECTOR_STABLE_SAMPLES) {
        selector_candidate_count++;
    }

    if (mode != SELECTOR_INVALID &&
        selector_candidate_count >= SELECTOR_STABLE_SAMPLES &&
        mode != selector_applied_mode) {
        selector_apply_local(mode);
    }

    /* Stable position is sampled slowly to save energy. If the first sample
     * suggests a real position change, take the second debounce sample quickly
     * so physical response remains close to the proven v0.21 behavior. */
    uint32_t next_sample_ms = SELECTOR_SAMPLE_MS;
    if (mode != SELECTOR_INVALID &&
        mode != selector_applied_mode &&
        selector_candidate_count < SELECTOR_STABLE_SAMPLES) {
        next_sample_ms = SELECTOR_CONFIRM_MS;
    }
    (void)k_work_reschedule(&selector_work, K_MSEC(next_sample_ms));
}

static void stats_save_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    (void)airwick_stats_save();
}

static void config_save_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    (void)airwick_config_save();
    (void)k_work_reschedule(&scheduler_work, K_NO_WAIT);
}

static void update_next_schedule_time(uint32_t now)
{
    uint32_t next = AIRWICK_TIME_INVALID;
    if (cfg->mode == AIRWICK_MODE_SCHEDULE || cfg->mode == AIRWICK_MODE_PROGRAMMABLE) {
        next = airwick_schedule_next(cfg, now, stats->last_schedule_token);
    }
    if (stats->next_spray_time != next) {
        stats->next_spray_time = next;
        schedule_stats_save();
        schedule_control_report();
    }
}

static void reconcile_auto_with_wall_clock(uint32_t now)
{
    int64_t deadline = auto_deadline_get();
    int64_t remaining_ms = deadline - k_uptime_get();
    if (deadline < 0 || remaining_ms <= 0) {
        /* A due AUTO spray must be processed before changing its deadline. */
        return;
    }
    uint32_t remaining = airwick_auto_remaining_seconds(remaining_ms);
    uint32_t projected_next = now + remaining;
    stats->fallback_remaining_sec = remaining;
    if (stats->next_spray_time != projected_next) {
        stats->next_spray_time = projected_next;
        schedule_stats_save();
        schedule_control_report();
    }
}

static void scheduler_reconcile(void)
{
    uint32_t now;
    bool valid = clock_now(&now);

    if (cfg->mode == AIRWICK_MODE_AUTO) {
        uint32_t full = (uint32_t)cfg->auto_interval_minute * 60U;
        int64_t deadline = auto_deadline_get();
        if (deadline < 0) {
            uint32_t remaining = stats->fallback_remaining_sec;
            if (remaining == 0U || remaining > full) {
                remaining = full;
            }
            auto_deadline_set(k_uptime_get() + (int64_t)remaining * 1000LL);
        }
        if (valid) {
            reconcile_auto_with_wall_clock(now);
        } else if (stats->next_spray_time != AIRWICK_TIME_INVALID) {
            stats->next_spray_time = AIRWICK_TIME_INVALID;
            schedule_control_report();
        }
    } else {
        auto_deadline_set(-1);
        if (valid) {
            update_next_schedule_time(now);
        } else if (stats->next_spray_time != AIRWICK_TIME_INVALID) {
            /* Cold boot without an RTC: never display or execute stale UTC. */
            stats->next_spray_time = AIRWICK_TIME_INVALID;
            schedule_control_report();
        }
    }
}

static void scheduler_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    if (atomic_get(&factory_reset_active) != 0) {
        return;
    }

    scheduler_reconcile();

    uint32_t now_utc;
    bool valid = clock_now(&now_utc);

    if (cfg->mode == AIRWICK_MODE_AUTO) {
        int64_t now_ms = k_uptime_get();
        int64_t deadline = auto_deadline_get();
        if (deadline >= 0 && now_ms >= deadline) {
            uint32_t interval_sec = (uint32_t)cfg->auto_interval_minute * 60U;
            int64_t interval_ms = (int64_t)interval_sec * 1000LL;
            /* Keep a fixed cadence anchored to the previous deadline. Scheduler latency,
             * manual sprays and the 5 s motor lockout must never shift future AUTO slots. */
            int64_t next_deadline = airwick_auto_next_deadline(deadline, now_ms, interval_ms);
            auto_deadline_set(next_deadline);
            uint32_t remaining = (uint32_t)((next_deadline - now_ms + 999LL) / 1000LL);
            stats->fallback_remaining_sec = remaining;
            stats->next_spray_time = valid ? now_utc + remaining : AIRWICK_TIME_INVALID;
            schedule_stats_save();
            schedule_control_report();
            (void)request_spray(SPRAY_REASON_AUTO);
        }
    } else if (valid &&
               (cfg->mode == AIRWICK_MODE_SCHEDULE ||
                cfg->mode == AIRWICK_MODE_PROGRAMMABLE)) {
        uint32_t token;
        uint8_t reason;
        if (airwick_schedule_due(cfg, now_utc, stats->last_schedule_token, &token, &reason)) {
            /* Token is committed before spray request, so a recent manual spray makes this event skipped. */
            stats->last_schedule_token = token;
            stats->next_spray_time = airwick_schedule_next(cfg, now_utc + 60U, token);
            schedule_stats_save();
            schedule_control_report();
            (void)request_spray((enum spray_reason)reason);
        }
    }

    uint32_t delay_ms = SCHEDULER_TICK_MS;
    if (cfg->mode == AIRWICK_MODE_AUTO) {
        int64_t remain = auto_deadline_get() - k_uptime_get();
        if (remain > 50) {
            delay_ms = (uint32_t)MIN(remain, (int64_t)UINT32_MAX);
        }
    } else if (cfg->mode == AIRWICK_MODE_SCHEDULE ||
               cfg->mode == AIRWICK_MODE_PROGRAMMABLE) {
        /* v0.22: the wall-clock scheduler already knows the exact next event.
         * Do not wake every 30 s while waiting. Any selector/config/time change
         * explicitly reschedules this work immediately elsewhere in the code. */
        if (valid && stats->next_spray_time != AIRWICK_TIME_INVALID &&
            stats->next_spray_time > now_utc) {
            uint64_t wait_ms =
                (uint64_t)(stats->next_spray_time - now_utc) * 1000ULL;
            delay_ms = (uint32_t)MIN(wait_ms, (uint64_t)UINT32_MAX);
        } else if (!valid || stats->next_spray_time == AIRWICK_TIME_INVALID) {
            /* Time-sync/config callbacks wake us immediately when something
             * becomes actionable; this is only a low-frequency safety fallback. */
            delay_ms = 10UL * 60UL * 1000UL;
        } else {
            /* If the target minute is already current, retry soon rather than
             * falling back to the old 30 s scan. */
            delay_ms = 1000U;
        }
    } else if (cfg->mode == AIRWICK_MODE_OFF) {
        delay_ms = 10UL * 60UL * 1000UL;
    }
    (void)k_work_reschedule(&scheduler_work, K_MSEC(delay_ms));
}

static zb_bool_t set_real_time_clock_cb(zb_uint32_t time)
{
    if (time == ZB_ZCL_TIME_TIME_INVALID_VALUE) {
        return ZB_FALSE;
    }
    clock_set(time);
    atomic_set(&clock_network_synced, 1);
    atomic_clear(&time_sync_attempts);
    time_cluster.time = time;
    time_cluster.time_status = 0x02;
    time_cluster.time_zone = (zb_int32_t)cfg->timezone_minutes * 60;
    time_cluster.standard_time = time + time_cluster.time_zone;
    time_cluster.local_time = time_cluster.standard_time;
    time_cluster.last_set_time = time;
    (void)k_work_reschedule(&clock_checkpoint_work, K_NO_WAIT);
    (void)k_work_reschedule(&time_sync_work, K_MSEC(TIME_SYNC_PERIOD_MS));
    scheduler_reconcile();
    (void)k_work_reschedule(&scheduler_work, K_NO_WAIT);
    schedule_control_report();
    return ZB_TRUE;
}

static void time_server_found_cb(zb_ret_t status, zb_uint32_t auth_level,
                                 zb_uint16_t short_addr, zb_uint8_t endpoint,
                                 zb_uint32_t nw_time)
{
    ARG_UNUSED(auth_level);
    ARG_UNUSED(short_addr);
    ARG_UNUSED(endpoint);
    if (status == RET_OK && nw_time != ZB_ZCL_TIME_TIME_INVALID_VALUE) {
        (void)set_real_time_clock_cb(nw_time);
    }
}

static void start_time_sync_zboss(zb_uint8_t unused)
{
    ARG_UNUSED(unused);
    if (atomic_get(&network_joined) != 0) {
        zb_zcl_time_server_synchronize(AIRWICK_ENDPOINT, time_server_found_cb);
    }
}

static void time_sync_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    if (atomic_get(&network_joined) == 0) {
        return;
    }

    (void)ZB_SCHEDULE_APP_CALLBACK(start_time_sync_zboss, 0);
    if (atomic_get(&clock_network_synced) == 0 && atomic_get(&time_sync_attempts) < UINT8_MAX) {
        atomic_inc(&time_sync_attempts);
    }
    (void)k_work_reschedule(&time_sync_work, K_MSEC(time_sync_retry_delay_ms()));
}

static uint16_t read_u16(const zb_uint8_t *value)
{
    uint16_t out;
    memcpy(&out, value, sizeof(out));
    return out;
}

static int16_t read_s16(const zb_uint8_t *value)
{
    int16_t out;
    memcpy(&out, value, sizeof(out));
    return out;
}

static uint32_t read_u32(const zb_uint8_t *value)
{
    uint32_t out;
    memcpy(&out, value, sizeof(out));
    return out;
}

static zb_ret_t control_check_value(zb_uint16_t attr_id, zb_uint8_t endpoint,
                                    zb_uint8_t *value)
{
    ARG_UNUSED(endpoint);

    if (attr_id == AW_ATTR_MODE) {
        return value[0] <= AIRWICK_MODE_PROGRAMMABLE ? RET_OK : RET_OUT_OF_RANGE;
    }
    if (attr_id == AW_ATTR_SPRAY_DURATION_MS) {
        uint16_t v = read_u16(value);
        return (v >= SPRAY_PULSE_MIN_MS && v <= SPRAY_PULSE_MAX_MS) ? RET_OK : RET_OUT_OF_RANGE;
    }
    if (attr_id == AW_ATTR_AUTO_INTERVAL_MIN || attr_id == AW_ATTR_SCHEDULE_INTERVAL_MIN) {
        uint16_t v = read_u16(value);
        return (v >= 1U && v <= 1440U) ? RET_OK : RET_OUT_OF_RANGE;
    }
    if (attr_id == AW_ATTR_SCHEDULE_DAYS) {
        return value[0] <= 0x7f ? RET_OK : RET_OUT_OF_RANGE;
    }
    if (attr_id == AW_ATTR_SCHEDULE_START_MIN || attr_id == AW_ATTR_SCHEDULE_END_MIN) {
        return read_u16(value) < 1440U ? RET_OK : RET_OUT_OF_RANGE;
    }
    if (attr_id == AW_ATTR_TIMEZONE_MIN) {
        int16_t v = read_s16(value);
        return (v >= -720 && v <= 840) ? RET_OK : RET_OUT_OF_RANGE;
    }
    if (attr_id == AW_ATTR_RESET_COUNTER) {
        return value[0] <= 1U ? RET_OK : RET_OUT_OF_RANGE;
    }
    if (attr_id == AW_ATTR_SYNC_TIME) {
        uint32_t v = read_u32(value);
        return v != AIRWICK_TIME_INVALID ? RET_OK : RET_OUT_OF_RANGE;
    }

    if (attr_id >= AW_PROGRAM_BASE && attr_id < AW_PROGRAM_BASE + AIRWICK_PROGRAM_SLOTS * AW_PROGRAM_STRIDE) {
        uint16_t rel = attr_id - AW_PROGRAM_BASE;
        uint8_t field = rel % AW_PROGRAM_STRIDE;
        if (field == AW_PROGRAM_ENABLED) {
            return value[0] <= 1U ? RET_OK : RET_OUT_OF_RANGE;
        }
        if (field == AW_PROGRAM_DAYS) {
            return value[0] <= 0x7f ? RET_OK : RET_OUT_OF_RANGE;
        }
        if (field == AW_PROGRAM_START || field == AW_PROGRAM_END) {
            return read_u16(value) < 1440U ? RET_OK : RET_OUT_OF_RANGE;
        }
        if (field == AW_PROGRAM_INTERVAL) {
            uint16_t v = read_u16(value);
            return (v >= 1U && v <= 1440U) ? RET_OK : RET_OUT_OF_RANGE;
        }
    }

    return RET_OK;
}

static void reset_counter_zboss(zb_uint8_t unused)
{
    ARG_UNUSED(unused);
    ctrl_reset_counter = ZB_FALSE;
    stats->spray_count = 0;
    spray_count = 0;
    ctrl_spray_count = 0;
    mark_control_attr(AW_ATTR_RESET_COUNTER);
    mark_control_attr(AW_ATTR_SPRAY_COUNT);
    schedule_stats_save();
}

static void control_write_hook(zb_uint8_t endpoint, zb_uint16_t attr_id,
                               zb_uint8_t *new_value, zb_uint16_t manuf_code)
{
    ARG_UNUSED(endpoint);
    ARG_UNUSED(manuf_code);
    bool config_changed = true;
    bool scheduler_changed = true;

    switch (attr_id) {
    case AW_ATTR_MODE:
        cfg->mode = new_value[0];
        break;
    case AW_ATTR_SPRAY_DURATION_MS:
        cfg->spray_duration_ms = read_u16(new_value);
        scheduler_changed = false; /* keep AUTO and wall-clock deadlines intact */
        break;
    case AW_ATTR_AUTO_INTERVAL_MIN:
        cfg->auto_interval_minute = read_u16(new_value);
        stats->fallback_remaining_sec = (uint32_t)cfg->auto_interval_minute * 60U;
        auto_deadline_set(k_uptime_get() + (int64_t)stats->fallback_remaining_sec * 1000LL);
        schedule_stats_save();
        break;
    case AW_ATTR_SCHEDULE_DAYS:
        cfg->schedule_days_mask = new_value[0];
        break;
    case AW_ATTR_SCHEDULE_START_MIN:
        cfg->schedule_start_minute = read_u16(new_value);
        break;
    case AW_ATTR_SCHEDULE_END_MIN:
        cfg->schedule_end_minute = read_u16(new_value);
        break;
    case AW_ATTR_SCHEDULE_INTERVAL_MIN:
        cfg->schedule_interval_minute = read_u16(new_value);
        break;
    case AW_ATTR_TIMEZONE_MIN:
        cfg->timezone_minutes = read_s16(new_value);
        time_cluster.time_zone = (zb_int32_t)cfg->timezone_minutes * 60;
        break;
    case AW_ATTR_RESET_COUNTER:
        config_changed = false;
        if (new_value[0] != 0U) {
            /* Deferred because the ZCL core writes the incoming value after this hook returns. */
            (void)ZB_SCHEDULE_APP_CALLBACK(reset_counter_zboss, 0);
        }
        break;
    case AW_ATTR_SYNC_TIME:
        config_changed = false;
        ctrl_sync_time = read_u32(new_value);
        (void)set_real_time_clock_cb(ctrl_sync_time);
        break;
    default:
        config_changed = false;
        if (attr_id >= AW_PROGRAM_BASE &&
            attr_id < AW_PROGRAM_BASE + AIRWICK_PROGRAM_SLOTS * AW_PROGRAM_STRIDE) {
            uint16_t rel = attr_id - AW_PROGRAM_BASE;
            uint8_t slot = rel / AW_PROGRAM_STRIDE;
            uint8_t field = rel % AW_PROGRAM_STRIDE;
            if (slot < AIRWICK_PROGRAM_SLOTS) {
                switch (field) {
                case AW_PROGRAM_ENABLED: cfg->program[slot].enabled = new_value[0] ? 1U : 0U; config_changed = true; break;
                case AW_PROGRAM_DAYS: cfg->program[slot].days_mask = new_value[0]; config_changed = true; break;
                case AW_PROGRAM_START: cfg->program[slot].start_minute = read_u16(new_value); config_changed = true; break;
                case AW_PROGRAM_END: cfg->program[slot].end_minute = read_u16(new_value); config_changed = true; break;
                case AW_PROGRAM_INTERVAL: cfg->program[slot].interval_minute = read_u16(new_value); config_changed = true; break;
                default: break;
                }
            }
        }
        break;
    }

    if (config_changed) {
        (void)k_work_reschedule(&config_save_work, K_NO_WAIT);
        if (scheduler_changed) {
            (void)k_work_reschedule(&scheduler_work, K_NO_WAIT);
        }
    }
}


enum pairing_led_state {
    PAIRING_LED_OFF = 0,
    PAIRING_LED_SEARCH = 1,
    PAIRING_LED_SUCCESS = 2,
};

static bool pairing_marker_load(void)
{
    uint8_t value = 0;
    ssize_t n = settings_load_one(PAIRING_KEY, &value, sizeof(value));
    return n == (ssize_t)sizeof(value) && value == 1U;
}

static int pairing_marker_set(bool pending)
{
    if (pending) {
        const uint8_t value = 1U;
        return settings_save_one(PAIRING_KEY, &value, sizeof(value));
    }
    return settings_delete(PAIRING_KEY);
}

static void pairing_led_stop(void)
{
    (void)k_work_cancel_delayable(&pairing_led_work);
    atomic_set(&pairing_led_mode, PAIRING_LED_OFF);
    atomic_clear(&pairing_led_on);
    pairing_led_phase = 0U;
    status_led_refresh();
}

static void pairing_led_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    atomic_val_t mode = atomic_get(&pairing_led_mode);

    if (mode == PAIRING_LED_SEARCH) {
        bool turn_on = atomic_get(&pairing_led_on) == 0;
        if (turn_on) {
            atomic_set(&pairing_led_on, 1);
        } else {
            atomic_clear(&pairing_led_on);
        }
        status_led_refresh();
        (void)k_work_reschedule(&pairing_led_work,
            K_MSEC(turn_on ? 180 : 820));
        return;
    }

    if (mode == PAIRING_LED_SUCCESS) {
        if (pairing_led_phase >= 6U) {
            atomic_set(&pairing_led_mode, PAIRING_LED_OFF);
            atomic_clear(&pairing_led_on);
            pairing_led_phase = 0U;
            status_led_refresh();
            return;
        }

        if ((pairing_led_phase & 1U) == 0U) {
            atomic_set(&pairing_led_on, 1);
        } else {
            atomic_clear(&pairing_led_on);
        }
        pairing_led_phase++;
        status_led_refresh();
        (void)k_work_reschedule(&pairing_led_work, K_MSEC(140));
        return;
    }

    atomic_clear(&pairing_led_on);
    status_led_refresh();
}

static void pairing_led_start_search(void)
{
    identify_stop();
    pairing_led_phase = 0U;
    atomic_clear(&pairing_led_on);
    atomic_set(&pairing_led_mode, PAIRING_LED_SEARCH);
    (void)k_work_reschedule(&pairing_led_work, K_NO_WAIT);
}

static void pairing_led_success(void)
{
    (void)k_work_cancel_delayable(&pairing_led_work);
    pairing_led_phase = 0U;
    atomic_clear(&pairing_led_on);
    atomic_set(&pairing_led_mode, PAIRING_LED_SUCCESS);
    (void)k_work_reschedule(&pairing_led_work, K_NO_WAIT);
}

static void pairing_reboot_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    sys_reboot(SYS_REBOOT_COLD);
}

static void pairing_start_steering_zboss(zb_uint8_t unused);

static void pairing_retry_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    if (!pairing_pending || k_uptime_get() >= pairing_deadline_ms) {
        return;
    }
    (void)ZB_SCHEDULE_APP_CALLBACK(pairing_start_steering_zboss, 0);
}

static void pairing_start_steering_zboss(zb_uint8_t unused)
{
    ARG_UNUSED(unused);
    if (!pairing_pending || atomic_get(&network_joined) != 0) {
        return;
    }
    if (k_uptime_get() >= pairing_deadline_ms) {
        pairing_led_stop();
        return;
    }

    /* Do not let the default exponential rejoin loop contend with explicit steering. */
    zigbee_network_rejoin_abort();
    zigbee_network_join_commissioning_set_active(false);

    if (bdb_start_top_level_commissioning(ZB_BDB_NETWORK_STEERING) == ZB_TRUE) {
        zigbee_network_join_commissioning_set_active(true);
    } else {
        (void)k_work_reschedule(&pairing_retry_work, K_MSEC(PAIRING_RETRY_MS));
    }
}

static void pairing_reset_zboss(zb_uint8_t unused)
{
    ARG_UNUSED(unused);
    motor_force_off_zboss();
    identify_stop();
    pairing_led_start_search();
    zb_bdb_reset_via_local_action(0);
}

static void button_short_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    if (!request_spray(SPRAY_REASON_BUTTON)) {
        (void)k_work_reschedule(&motor_state_sync_work, K_NO_WAIT);
    }
}

static void pairing_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    atomic_set(&factory_reset_active, 1);
    atomic_clear(&network_joined);
    (void)k_work_cancel_delayable(&scheduler_work);
    (void)k_work_cancel_delayable(&time_sync_work);
    (void)k_work_cancel_delayable(&pairing_retry_work);

    /* v0.10: make factory reset deterministic across a reboot boundary.
     * The application settings are erased now; a persistent one-shot marker
     * tells the next boot to erase ZBOSS NVRAM before Zigbee stack startup. */
    (void)airwick_state_factory_erase();
    (void)settings_delete(CLOCK_KEY);
    (void)k_work_cancel_delayable(&clock_checkpoint_work);
    pairing_pending = true;
    (void)pairing_marker_set(true);
    pairing_led_start_search();

    /* settings_save_one() is synchronous. Reboot shortly after the visual ack. */
    (void)k_work_reschedule(&pairing_reboot_work, K_MSEC(350));
}

static void button_hold_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    if (button_pressed && gpio_pin_get_dt(&action_button) > 0) {
        atomic_set(&button_long_fired, 1);
        (void)k_work_submit(&pairing_work);
    }
}

static void button_gpio_handler(const struct device *port,
                                struct gpio_callback *cb,
                                gpio_port_pins_t pins)
{
    ARG_UNUSED(port);
    ARG_UNUSED(cb);
    ARG_UNUSED(pins);

    bool pressed = gpio_pin_get_dt(&action_button) > 0;
    if (pressed && !button_pressed) {
        button_pressed = true;
        atomic_clear(&button_long_fired);
        (void)k_work_reschedule(&button_hold_work, K_MSEC(BUTTON_HOLD_MS));
    } else if (!pressed && button_pressed) {
        button_pressed = false;
        (void)k_work_cancel_delayable(&button_hold_work);
        if (atomic_get(&button_long_fired) == 0) {
            (void)k_work_submit(&button_short_work);
        }
    }
}

static void network_recovery_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);
    if (!pairing_pending && atomic_get(&factory_reset_active) == 0 &&
        atomic_get(&network_joined) == 0) {
        sys_reboot(SYS_REBOOT_COLD);
    }
}

static void zboss_heartbeat_zboss(zb_uint8_t unused)
{
    ARG_UNUSED(unused);
    atomic_inc(&zboss_heartbeat_counter);
    atomic_clear(&health_probe_pending);
}

static void health_work_handler(struct k_work *work)
{
    ARG_UNUSED(work);

    if (watchdog_channel >= 0) {
        (void)wdt_feed(watchdog_dev, watchdog_channel);
    }

    if (atomic_get(&network_joined) != 0 && !pairing_pending &&
        atomic_get(&factory_reset_active) == 0) {
        atomic_val_t current = atomic_get(&zboss_heartbeat_counter);
        if (atomic_get(&health_probe_pending) != 0) {
            if (current == health_last_heartbeat) {
                if (health_missed_heartbeats < UINT8_MAX) {
                    health_missed_heartbeats++;
                }
            } else {
                health_missed_heartbeats = 0U;
            }
        } else if (current != health_last_heartbeat) {
            health_missed_heartbeats = 0U;
        }
        health_last_heartbeat = current;

        if (health_missed_heartbeats >= ZBOSS_HEALTH_MAX_MISSES) {
            sys_reboot(SYS_REBOOT_COLD);
        }

        zb_ret_t probe_rc = ZB_SCHEDULE_APP_CALLBACK(zboss_heartbeat_zboss, 0);
        atomic_set(&health_probe_pending, probe_rc == RET_OK ? 1 : 0);
    } else {
        health_last_heartbeat = atomic_get(&zboss_heartbeat_counter);
        health_missed_heartbeats = 0U;
        atomic_clear(&health_probe_pending);
    }

    (void)k_work_reschedule(&health_work, K_MSEC(ZBOSS_HEALTH_PERIOD_MS));
}

static void watchdog_start(void)
{
    if (!device_is_ready(watchdog_dev)) {
        return;
    }
    struct wdt_timeout_cfg cfg_wdt = {
        .flags = WDT_FLAG_RESET_SOC,
        .window = {
            .min = 0U,
            .max = HW_WATCHDOG_TIMEOUT_MS,
        },
        .callback = NULL,
    };
    int ch = wdt_install_timeout(watchdog_dev, &cfg_wdt);
    if (ch < 0) {
        return;
    }
    if (wdt_setup(watchdog_dev, 0U) == 0) {
        watchdog_channel = ch;
        (void)wdt_feed(watchdog_dev, watchdog_channel);
    }
}

static void zcl_device_cb(zb_bufid_t bufid)
{
    zb_zcl_device_callback_param_t *cb =
        ZB_BUF_GET_PARAM(bufid, zb_zcl_device_callback_param_t);
    cb->status = RET_OK;
    if (cb->device_cb_id != ZB_ZCL_SET_ATTR_VALUE_CB_ID) {
        return;
    }

    if (cb->endpoint != AIRWICK_ENDPOINT) {
        return;
    }

    zb_uint16_t cluster_id = cb->cb_param.set_attr_value_param.cluster_id;
    zb_uint16_t attr_id = cb->cb_param.set_attr_value_param.attr_id;

    if (cluster_id == ZB_ZCL_CLUSTER_ID_IDENTIFY &&
        attr_id == ZB_ZCL_ATTR_IDENTIFY_IDENTIFY_TIME_ID) {
        if (pairing_pending || atomic_get(&factory_reset_active) != 0 || !ZB_JOINED()) {
            identify_stop();
        } else {
            identify_start(cb->cb_param.set_attr_value_param.values.data16);
        }
        return;
    }

    if (cluster_id == ZB_ZCL_CLUSTER_ID_TIME &&
        attr_id == ZB_ZCL_ATTR_TIME_TIME_ID) {
        (void)set_real_time_clock_cb(cb->cb_param.set_attr_value_param.values.data32);
        return;
    }

    if (cluster_id != ZB_ZCL_CLUSTER_ID_ON_OFF) {
        return;
    }

    if (attr_id == ZB_ZCL_ATTR_ON_OFF_START_UP_ON_OFF) {
        cfg->startup_on_off = cb->cb_param.set_attr_value_param.values.data8;
        (void)k_work_reschedule(&config_save_work, K_NO_WAIT);
        return;
    }

    if (attr_id != ZB_ZCL_ATTR_ON_OFF_ON_OFF_ID) {
        return;
    }

    if (!cb->cb_param.set_attr_value_param.values.data8) {
        motor_force_off_zboss();
        return;
    }

    if (!request_spray(SPRAY_REASON_REMOTE)) {
        /* Deferred: the ZCL core writes the incoming ON after this callback returns. */
        ZB_ERROR_CHECK(ZB_SCHEDULE_APP_CALLBACK(finish_spray_zboss, 0));
    }
}

static void safety_for_network_event(zb_zdo_app_signal_type_t sig)
{
    switch (sig) {
    case ZB_BDB_SIGNAL_DEVICE_FIRST_START:
    case ZB_BDB_SIGNAL_DEVICE_REBOOT:
    case ZB_BDB_SIGNAL_STEERING:
    case ZB_ZDO_SIGNAL_LEAVE:
    case ZB_NWK_SIGNAL_NO_ACTIVE_LINKS_LEFT:
        motor_force_off_zboss();
        identify_stop();
        break;
    default:
        break;
    }
}

void zboss_signal_handler(zb_bufid_t bufid)
{
    zb_zdo_app_signal_hdr_t *sig_hndler = NULL;
    zb_zdo_app_signal_type_t sig = zb_get_app_signal(bufid, &sig_hndler);
    zb_ret_t status = ZB_GET_APP_SIGNAL_STATUS(bufid);

    if (sig == ZB_BDB_SIGNAL_DEVICE_FIRST_START ||
        sig == ZB_BDB_SIGNAL_DEVICE_REBOOT ||
        sig == ZB_BDB_SIGNAL_STEERING) {
        joining_signal_received = true;
    }

    if (sig == ZB_ZDO_SIGNAL_LEAVE && status == RET_OK) {
        zb_zdo_signal_leave_params_t *leave_params =
            ZB_ZDO_SIGNAL_GET_PARAMS(sig_hndler, zb_zdo_signal_leave_params_t);
        if (leave_params->leave_type == ZB_NWK_LEAVE_TYPE_REJOIN) {
            joining_signal_received = false;
        }
    }

    if (sig == ZB_NLME_STATUS_INDICATION) {
        zb_zdo_signal_nlme_status_indication_params_t *nlme_status_ind =
            ZB_ZDO_SIGNAL_GET_PARAMS(sig_hndler,
                zb_zdo_signal_nlme_status_indication_params_t);
        if (nlme_status_ind->nlme_status.status == ZB_NWK_COMMAND_STATUS_PARENT_LINK_FAILURE) {
            atomic_clear(&network_joined);
            (void)k_work_reschedule(&network_recovery_work,
                K_MSEC(joining_signal_received ? NETWORK_RECOVERY_MS : 5000U));
        }
    }

    safety_for_network_event(sig);

    /* Nordic KRKNWK-8200: ZBOSS can report successful steering even when
     * commissioning actually failed during Trust Center key exchange.  Treat
     * a zero/invalid Extended PAN ID as failure before the default BDB handler
     * sees the signal. */
    if (sig == ZB_BDB_SIGNAL_STEERING && status == RET_OK) {
        zb_ext_pan_id_t extended_pan_id;
        zb_get_extended_pan_id(extended_pan_id);
        if (!ZB_IEEE_ADDR_IS_VALID(extended_pan_id)) {
            status = (zb_ret_t)-1;
            zb_buf_set_status(bufid, status);
        }
    }

    if (pairing_pending) {
        switch (sig) {
        case ZB_BDB_SIGNAL_DEVICE_FIRST_START:
            atomic_clear(&network_joined);
            /* A sleepy device needs fast polling while association/TCLK
             * exchange is in progress. Do not enter normal battery polling yet. */
            zb_zdo_pim_permit_turbo_poll(ZB_TRUE);
            pairing_led_start_search();
            break;

        case ZB_BDB_SIGNAL_STEERING:
            if (status == RET_OK) {
                pairing_pending = false;
                (void)pairing_marker_set(false);
                atomic_clear(&factory_reset_active);
                pairing_led_success();
            } else {
                atomic_clear(&network_joined);
                zb_zdo_pim_permit_turbo_poll(ZB_TRUE);
                pairing_led_start_search();
            }
            break;

        case ZB_ZDO_SIGNAL_LEAVE:
            atomic_clear(&network_joined);
            zb_zdo_pim_permit_turbo_poll(ZB_TRUE);
            pairing_led_start_search();
            break;

        default:
            break;
        }
    }

    /* Preserve v0.10's proven Nordic BDB commissioning/retry state machine. */
    ZB_ERROR_CHECK(zigbee_default_signal_handler(bufid));

    if (sig == ZB_ZDO_SIGNAL_LEAVE || sig == ZB_NWK_SIGNAL_NO_ACTIVE_LINKS_LEFT) {
        atomic_clear(&network_joined);
        if (!pairing_pending && atomic_get(&factory_reset_active) == 0) {
            (void)k_work_reschedule(&network_recovery_work, K_MSEC(NETWORK_RECOVERY_MS));
        }
    }

    /* Signal status alone is insufficient: require actual network membership. */
    bool network_ready = status == RET_OK && ZB_JOINED() &&
        (sig == ZB_BDB_SIGNAL_DEVICE_REBOOT || sig == ZB_BDB_SIGNAL_STEERING);

    if (network_ready) {
        atomic_set(&network_joined, 1);
        joining_signal_received = true;
        (void)k_work_cancel_delayable(&network_recovery_work);
        health_last_heartbeat = atomic_get(&zboss_heartbeat_counter);
        health_missed_heartbeats = 0U;
        atomic_clear(&health_probe_pending);
        atomic_clear(&time_sync_attempts);
        (void)ZB_SCHEDULE_APP_CALLBACK(zboss_heartbeat_zboss, 0);
        /* Nordic workaround: only now is it safe to leave commissioning polling. */
        zb_zdo_pim_permit_turbo_poll(ZB_FALSE);
        zb_zdo_pim_set_long_poll_interval(BATTERY_LONG_POLL_MS);
        start_battery_sampling();
        schedule_control_report();
        schedule_state_report_retry();
        (void)k_work_reschedule(&scheduler_work, K_NO_WAIT);
        (void)k_work_reschedule(&time_sync_work, K_MSEC(TIME_SYNC_INITIAL_MS));
    }

    if (bufid) {
        zb_buf_free(bufid);
    }
}

int main(void)
{
    if (!gpio_is_ready_dt(&motor_out) ||
        gpio_pin_configure_dt(&motor_out, GPIO_OUTPUT_INACTIVE) != 0) {
        return 0;
    }

    if (!gpio_is_ready_dt(&selector_power) ||
        gpio_pin_configure_dt(&selector_power, GPIO_OUTPUT_INACTIVE) != 0) {
        return 0;
    }

    if (gpio_is_ready_dt(&status_led)) {
        (void)gpio_pin_configure_dt(&status_led, GPIO_OUTPUT_INACTIVE);
    }

    if (!gpio_is_ready_dt(&action_button) ||
        gpio_pin_configure_dt(&action_button, GPIO_INPUT) != 0) {
        return 0;
    }

    if (!adc_is_ready_dt(&battery_adc) || adc_channel_setup_dt(&battery_adc) != 0) {
        return 0;
    }
    if (!adc_is_ready_dt(&selector_adc) || adc_channel_setup_dt(&selector_adc) != 0) {
        return 0;
    }

    atomic_clear(&pulse_active);
    atomic_clear(&identify_led_on);
    atomic_clear(&button_long_fired);
    atomic_clear(&network_joined);
    atomic_clear(&factory_reset_active);
    atomic_clear(&pairing_led_on);
    atomic_set(&pairing_led_mode, PAIRING_LED_OFF);
    atomic_clear(&zboss_heartbeat_counter);
    atomic_clear(&clock_network_synced);
    health_last_heartbeat = 0;
    health_missed_heartbeats = 0U;
    atomic_clear(&health_probe_pending);
    atomic_clear(&time_sync_attempts);
    joining_signal_received = false;
    motor_physical_set(false);

    k_timer_init(&motor_cutoff_timer, motor_cutoff_expiry, NULL);
    k_work_init_delayable(&motor_state_sync_work, motor_state_sync_handler);
    k_work_init_delayable(&identify_work, identify_work_handler);
    k_work_init_delayable(&button_hold_work, button_hold_handler);
    k_work_init_delayable(&config_save_work, config_save_work_handler);
    k_work_init_delayable(&stats_save_work, stats_save_work_handler);
    k_work_init_delayable(&scheduler_work, scheduler_work_handler);
    k_work_init_delayable(&time_sync_work, time_sync_work_handler);
    k_work_init_delayable(&clock_checkpoint_work, clock_checkpoint_save_work_handler);
    k_work_init(&control_report_work, control_report_work_handler);
    k_work_init(&button_short_work, button_short_work_handler);
    k_work_init(&pairing_work, pairing_work_handler);
    k_work_init_delayable(&pairing_led_work, pairing_led_work_handler);
    k_work_init_delayable(&pairing_retry_work, pairing_retry_work_handler);
    k_work_init_delayable(&pairing_reboot_work, pairing_reboot_work_handler);
    k_work_init_delayable(&selector_work, selector_work_handler);
    k_work_init_delayable(&state_report_retry_work, state_report_retry_work_handler);
    k_work_init_delayable(&network_recovery_work, network_recovery_work_handler);
    k_work_init_delayable(&health_work, health_work_handler);

    gpio_init_callback(&button_gpio_cb, button_gpio_handler, BIT(action_button.pin));
    if (gpio_add_callback(action_button.port, &button_gpio_cb) != 0 ||
        gpio_pin_interrupt_configure_dt(&action_button, GPIO_INT_EDGE_BOTH) != 0) {
        return 0;
    }

    if (airwick_state_init() != 0) {
        return 0;
    }
    cfg = airwick_config_get();
    stats = airwick_stats_get();
    if (cfg->selector_enabled == 0U) {
        cfg->selector_enabled = 1U;
        (void)airwick_config_save();
    }
    pairing_pending = pairing_marker_load();
    if (pairing_pending) {
        atomic_set(&factory_reset_active, 1);
        pairing_deadline_ms = k_uptime_get() + (int64_t)PAIRING_WINDOW_MS;
        pairing_led_start_search();
    }
    spray_count = stats->spray_count;
    last_spray_reason = (enum spray_reason)stats->last_spray_reason;

    /* Compatibility cleanup for state written by v0.8-v0.10; never used again. */
    if (stats->controlled_reboot) {
        stats->controlled_reboot = 0;
        (void)airwick_stats_save();
    }

    uint32_t full_auto = (uint32_t)cfg->auto_interval_minute * 60U;
    uint32_t remaining = stats->fallback_remaining_sec;
    if (remaining == 0U || remaining > full_auto) {
        remaining = full_auto;
    }
    stats->fallback_remaining_sec = remaining;
    if (cfg->mode == AIRWICK_MODE_AUTO) {
        auto_deadline_set(k_uptime_get() + (int64_t)remaining * 1000LL);
    }

    power_source = ZB_ZCL_BASIC_POWER_SOURCE_BATTERY;
    control_from_persistent_state();

    ZB_AF_REGISTER_DEVICE_CTX(&airwick_ctx);
    ZB_ZCL_REGISTER_DEVICE_CB(zcl_device_cb);
    (void)zb_zcl_add_cluster_handlers(AIRWICK_CTRL,
        ZB_ZCL_CLUSTER_SERVER_ROLE, control_check_value, control_write_hook, NULL);
    ZB_ZCL_TIME_SET_REAL_TIME_CLOCK_CB(set_real_time_clock_cb);

    zb_set_ed_timeout(ED_AGING_TIMEOUT_64MIN);
    zb_set_keepalive_timeout(ZB_MILLISECONDS_TO_BEACON_INTERVAL(KEEPALIVE_MS));
    if (pairing_pending) {
        zigbee_erase_persistent_storage(ZB_TRUE);
    }
    /* Fixed v0.11 policy: always battery-style sleepy End Device.
     * USB can power/charge the board electrically but has zero firmware effect. */
    zigbee_configure_sleepy_behavior(true);
    zigbee_enable();
    watchdog_start();

    (void)k_work_reschedule(&health_work, K_MSEC(ZBOSS_HEALTH_PERIOD_MS));
    (void)k_work_reschedule(&scheduler_work, K_MSEC(1000));
    (void)k_work_reschedule(&selector_work, K_MSEC(250));
    return 0;
}

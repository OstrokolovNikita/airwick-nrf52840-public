#include "airwick_state.h"

#include <errno.h>
#include <string.h>
#include <zephyr/settings/settings.h>

#define AIRWICK_CONFIG_MAGIC UINT32_C(0x41574338) /* AWC8 */
#define AIRWICK_STATS_MAGIC  UINT32_C(0x41575338) /* AWS8 */
#define AIRWICK_CONFIG_VERSION 2U
#define AIRWICK_STATS_VERSION  1U

#define CONFIG_KEY "airwick/config"
#define STATS_KEY  "airwick/stats"

static struct airwick_config config_state;
static struct airwick_stats stats_state;

void airwick_config_defaults(struct airwick_config *cfg)
{
    memset(cfg, 0, sizeof(*cfg));
    cfg->magic = AIRWICK_CONFIG_MAGIC;
    cfg->version = AIRWICK_CONFIG_VERSION;
    cfg->size = sizeof(*cfg);

    /* Safe first boot: no automatic spray until a mode is explicitly selected. */
    cfg->mode = AIRWICK_MODE_OFF;
    cfg->timezone_minutes = 180; /* default UTC+3; writable later from Zigbee2MQTT */
    cfg->auto_interval_minute = 30;
    cfg->spray_duration_ms = 600;

    /* The original intended weekday schedule. */
    cfg->schedule_days_mask = 0x1f; /* Monday-Friday */
    cfg->schedule_start_minute = 7U * 60U;
    cfg->schedule_end_minute = 22U * 60U;
    cfg->schedule_interval_minute = 30;

    /* Keep the Z2M power-on-behavior preference, but motor is always physically OFF at boot. */
    cfg->startup_on_off = 0xff; /* previous */

    /* Hardware selector is deliberately disabled until the resistor ladder is actually fitted. */
    cfg->selector_enabled = 0;

    /* One independent programmable window per weekday. Disabled until the user
     * explicitly enables that day in Zigbee2MQTT. */
    for (unsigned int i = 0; i < AIRWICK_PROGRAM_SLOTS; i++) {
        cfg->program[i].enabled = 0;
        cfg->program[i].days_mask = (uint8_t)(1U << i);
        cfg->program[i].start_minute = 8U * 60U;
        cfg->program[i].end_minute = 20U * 60U;
        cfg->program[i].interval_minute = 30;
    }
}

void airwick_stats_defaults(struct airwick_stats *stats)
{
    memset(stats, 0, sizeof(*stats));
    stats->magic = AIRWICK_STATS_MAGIC;
    stats->version = AIRWICK_STATS_VERSION;
    stats->size = sizeof(*stats);
    stats->last_spray_time = AIRWICK_TIME_INVALID;
    stats->next_spray_time = AIRWICK_TIME_INVALID;
    stats->last_schedule_token = AIRWICK_TIME_INVALID;
    stats->fallback_remaining_sec = 30U * 60U;
    stats->last_spray_reason = AIRWICK_REASON_NONE;
}

static bool interval_valid(uint16_t value)
{
    return value >= 1U && value <= AIRWICK_MINUTES_PER_DAY;
}

bool airwick_config_valid(const struct airwick_config *cfg)
{
    if (cfg->magic != AIRWICK_CONFIG_MAGIC ||
        cfg->version != AIRWICK_CONFIG_VERSION ||
        cfg->size != sizeof(*cfg) ||
        cfg->mode > AIRWICK_MODE_PROGRAMMABLE ||
        cfg->schedule_days_mask > 0x7f ||
        cfg->timezone_minutes < -720 || cfg->timezone_minutes > 840 ||
        !interval_valid(cfg->auto_interval_minute) ||
        cfg->schedule_start_minute >= AIRWICK_MINUTES_PER_DAY ||
        cfg->schedule_end_minute >= AIRWICK_MINUTES_PER_DAY ||
        !interval_valid(cfg->schedule_interval_minute) ||
        cfg->selector_enabled > 1U ||
        (cfg->spray_duration_ms != 0U &&
         (cfg->spray_duration_ms < 300U || cfg->spray_duration_ms > 1000U))) {
        return false;
    }

    if (!(cfg->startup_on_off == 0x00 || cfg->startup_on_off == 0x01 ||
          cfg->startup_on_off == 0x02 || cfg->startup_on_off == 0xff)) {
        return false;
    }

    for (unsigned int i = 0; i < AIRWICK_PROGRAM_SLOTS; i++) {
        const struct airwick_program_slot *slot = &cfg->program[i];
        if (slot->enabled > 1U || slot->days_mask > 0x7f ||
            slot->start_minute >= AIRWICK_MINUTES_PER_DAY ||
            slot->end_minute >= AIRWICK_MINUTES_PER_DAY ||
            !interval_valid(slot->interval_minute)) {
            return false;
        }
    }
    return true;
}

bool airwick_stats_valid(const struct airwick_stats *stats)
{
    return stats->magic == AIRWICK_STATS_MAGIC &&
           stats->version == AIRWICK_STATS_VERSION &&
           stats->size == sizeof(*stats) &&
           stats->last_spray_reason <= AIRWICK_REASON_PROGRAMMABLE &&
           stats->controlled_reboot <= 1U;
}


/* v0.15 persistent config: same prefix but four program slots. */
struct airwick_config_v1 {
    uint32_t magic;
    uint16_t version;
    uint16_t size;

    uint8_t mode;
    uint8_t schedule_days_mask;
    int16_t timezone_minutes;

    uint16_t auto_interval_minute;
    uint16_t schedule_start_minute;
    uint16_t schedule_end_minute;
    uint16_t schedule_interval_minute;

    uint8_t startup_on_off;
    uint8_t selector_enabled;
    uint16_t reserved0;

    struct airwick_program_slot program[4];
};

static bool airwick_config_v1_valid(const struct airwick_config_v1 *old)
{
    if (old->magic != AIRWICK_CONFIG_MAGIC || old->version != 1U ||
        old->size != sizeof(*old) || old->mode > AIRWICK_MODE_PROGRAMMABLE ||
        old->timezone_minutes < -720 || old->timezone_minutes > 840 ||
        !interval_valid(old->auto_interval_minute)) {
        return false;
    }
    const struct airwick_program_slot *p0 = &old->program[0];
    return p0->days_mask <= 0x7f && p0->start_minute < AIRWICK_MINUTES_PER_DAY &&
           p0->end_minute < AIRWICK_MINUTES_PER_DAY && interval_valid(p0->interval_minute);
}

static void airwick_config_migrate_v1(const struct airwick_config_v1 *old)
{
    airwick_config_defaults(&config_state);

    config_state.mode = old->mode;
    config_state.timezone_minutes = old->timezone_minutes;
    config_state.auto_interval_minute = old->auto_interval_minute;
    config_state.startup_on_off = old->startup_on_off;
    config_state.selector_enabled = old->selector_enabled;

    /* v0.15 exposed one weekly program (slot 0 + day mask). Convert it into
     * seven independent weekday rows without changing its behavior. */
    const struct airwick_program_slot *p0 = &old->program[0];
    for (unsigned int i = 0; i < AIRWICK_PROGRAM_SLOTS; i++) {
        config_state.program[i].enabled = (p0->days_mask & (uint8_t)(1U << i)) ? 1U : 0U;
        config_state.program[i].days_mask = (uint8_t)(1U << i);
        config_state.program[i].start_minute = p0->start_minute;
        config_state.program[i].end_minute = p0->end_minute;
        config_state.program[i].interval_minute = p0->interval_minute;
    }
}

int airwick_state_init(void)
{
    int rc = settings_subsys_init();
    if (rc != 0 && rc != -EALREADY) {
        return rc;
    }

    struct airwick_config loaded_config = {0};
    ssize_t n = settings_load_one(CONFIG_KEY, &loaded_config, sizeof(loaded_config));
    bool have_config = false;

    if (n == (ssize_t)sizeof(loaded_config) && airwick_config_valid(&loaded_config)) {
        config_state = loaded_config;
        have_config = true;
    } else if (n == (ssize_t)sizeof(struct airwick_config_v1)) {
        struct airwick_config_v1 old;
        memcpy(&old, &loaded_config, sizeof(old));
        if (airwick_config_v1_valid(&old)) {
            airwick_config_migrate_v1(&old);
            have_config = true;
            rc = settings_save_one(CONFIG_KEY, &config_state, sizeof(config_state));
            if (rc != 0) {
                return rc;
            }
        }
    }

    if (!have_config) {
        airwick_config_defaults(&config_state);
        rc = settings_save_one(CONFIG_KEY, &config_state, sizeof(config_state));
        if (rc != 0) {
            return rc;
        }
    }

    struct airwick_stats loaded_stats;
    n = settings_load_one(STATS_KEY, &loaded_stats, sizeof(loaded_stats));
    if (n == (ssize_t)sizeof(loaded_stats) && airwick_stats_valid(&loaded_stats)) {
        stats_state = loaded_stats;
    } else {
        airwick_stats_defaults(&stats_state);
        stats_state.fallback_remaining_sec =
            (uint32_t)config_state.auto_interval_minute * 60U;
        rc = settings_save_one(STATS_KEY, &stats_state, sizeof(stats_state));
        if (rc != 0) {
            return rc;
        }
    }

    return 0;
}

struct airwick_config *airwick_config_get(void)
{
    return &config_state;
}

struct airwick_stats *airwick_stats_get(void)
{
    return &stats_state;
}

int airwick_config_save(void)
{
    if (!airwick_config_valid(&config_state)) {
        return -EINVAL;
    }
    return settings_save_one(CONFIG_KEY, &config_state, sizeof(config_state));
}

int airwick_stats_save(void)
{
    if (!airwick_stats_valid(&stats_state)) {
        return -EINVAL;
    }
    return settings_save_one(STATS_KEY, &stats_state, sizeof(stats_state));
}

int airwick_state_factory_erase(void)
{
    int first_error = 0;
    int rc = settings_delete(CONFIG_KEY);
    if (rc != 0 && rc != -ENOENT) {
        first_error = rc;
    }
    rc = settings_delete(STATS_KEY);
    if (rc != 0 && rc != -ENOENT && first_error == 0) {
        first_error = rc;
    }

    /* RAM defaults immediately; after BDB reset/reboot the same defaults are recreated in NVS. */
    airwick_config_defaults(&config_state);
    airwick_stats_defaults(&stats_state);
    return first_error;
}
